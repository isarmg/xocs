use crate::{FixedOutputReset, Mac, common_types::KeyInit};

/// Tag truncation side used in MAC tests
#[derive(Clone, Copy, Debug)]
pub enum MacTruncSide {
    /// Tag truncated from left (i.e. `tag[..n]`)
    Left,
    /// Tag truncated from right (i.e. `tag[n..]`)
    Right,
    /// Tag is not truncated
    None,
}

/// MAC test vector
#[derive(Debug, Clone, Copy)]
pub struct MacTestVector {
    /// Initialization key
    pub key: &'static [u8],
    /// Input message
    pub input: &'static [u8],
    /// Output tag
    pub tag: &'static [u8],
}

/// Run MAC test
pub fn mac_test<M: Mac + KeyInit + Clone>(
    &MacTestVector { key, input, tag }: &MacTestVector,
    trunc_side: MacTruncSide,
) -> Result<(), &'static str> {
    let Ok(mac0) = <M as KeyInit>::new_from_slice(key) else {
        return Err("Failed to initialize MAC instance");
    };

    initialized_mac_test(mac0, input, tag, trunc_side)
}

/// Run the MAC test directly on an initialized MAC.
/// This is useful for when custom initialization is needed
pub fn initialized_mac_test<M: Mac + Clone>(
    mac0: M,
    input: &[u8],
    tag: &[u8],
    trunc_side: MacTruncSide,
) -> Result<(), &'static str> {
    let mut mac = mac0.clone();
    mac.update(input);
    let result = mac.finalize().into_bytes();
    let n = tag.len();
    let result_bytes = match trunc_side {
        MacTruncSide::Left => &result[..n],
        MacTruncSide::Right => &result[result.len() - n..],
        MacTruncSide::None => &result[..],
    };
    if result_bytes != tag {
        return Err("whole message");
    }

    // test reading different chunk sizes
    for chunk_size in 1..core::cmp::min(64, input.len()) {
        let mut mac = mac0.clone();
        for chunk in input.chunks(chunk_size) {
            mac.update(chunk);
        }
        let res = match trunc_side {
            MacTruncSide::Left => mac.verify_truncated_left(tag),
            MacTruncSide::Right => mac.verify_truncated_right(tag),
            MacTruncSide::None => mac.verify_slice(tag),
        };
        if res.is_err() {
            return Err("chunked message");
        }
    }

    Ok(())
}

/// Run resettable MAC test
pub fn reset_mac_test<M: Mac + KeyInit + FixedOutputReset + Clone>(
    &MacTestVector { key, input, tag }: &MacTestVector,
    trunc_side: MacTruncSide,
) -> Result<(), &'static str> {
    let Ok(mac0) = <M as KeyInit>::new_from_slice(key) else {
        return Err("Failed to initialize MAC instance");
    };

    let mut mac = mac0.clone();
    Mac::update(&mut mac, input);
    let result = mac.finalize_reset().into_bytes();
    let n = tag.len();
    let result_bytes = match trunc_side {
        MacTruncSide::Left => &result[..n],
        MacTruncSide::Right => &result[result.len() - n..],
        MacTruncSide::None => &result[..],
    };
    if result_bytes != tag {
        return Err("whole message");
    }

    // test if reset worked correctly
    Mac::update(&mut mac, input);
    let res = match trunc_side {
        MacTruncSide::Left => mac.verify_truncated_left(tag),
        MacTruncSide::Right => mac.verify_truncated_right(tag),
        MacTruncSide::None => mac.verify_slice(tag),
    };
    if res.is_err() {
        return Err("after reset");
    }

    // test reading different chunk sizes
    for chunk_size in 1..core::cmp::min(64, input.len()) {
        let mut mac = mac0.clone();
        for chunk in input.chunks(chunk_size) {
            Mac::update(&mut mac, chunk);
        }
        let res = match trunc_side {
            MacTruncSide::Left => mac.verify_truncated_left(tag),
            MacTruncSide::Right => mac.verify_truncated_right(tag),
            MacTruncSide::None => mac.verify_slice(tag),
        };
        if res.is_err() {
            return Err("chunked message");
        }
    }

    Ok(())
}
