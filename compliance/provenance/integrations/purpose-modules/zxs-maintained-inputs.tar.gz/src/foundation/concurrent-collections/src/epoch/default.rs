//! The default garbage collector.
//!
//! For each thread, a participant is lazily initialized on its first use, when the current thread
//! is registered in the default collector.  If initialized, the thread's participant will get
//! destructed on thread exit, which in turn unregisters the thread.

use crate::epoch::collector::{Collector, LocalHandle};
use crate::epoch::guard::Guard;
use crate::epoch::primitive::thread_local;
#[cfg(not(crossbeam_loom))]
use crate::epoch::sync::once_lock::OnceLock;

fn collector() -> &'static Collector {
    #[cfg(not(crossbeam_loom))]
    {
        /// The global data for the default garbage collector.
        static COLLECTOR: OnceLock<Collector> = OnceLock::new();
        COLLECTOR.get_or_init(Collector::new)
    }
    // FIXME: loom does not currently provide the equivalent of Lazy:
    // https://github.com/tokio-rs/loom/issues/263
    #[cfg(crossbeam_loom)]
    {
        loom::lazy_static! {
            /// The global data for the default garbage collector.
            static ref COLLECTOR: Collector = Collector::new();
        }
        &COLLECTOR
    }
}

thread_local! {
    /// The per-thread participant for the default garbage collector.
    static HANDLE: LocalHandle = collector().register();
}

/// Pins the current thread.
#[inline]
pub fn pin() -> Guard {
    with_handle(|handle| handle.pin())
}

/// Returns `true` if the current thread is pinned.
#[inline]
pub fn is_pinned() -> bool {
    with_handle(|handle| handle.is_pinned())
}

/// Returns the default global collector.
pub fn default_collector() -> &'static Collector {
    collector()
}

#[inline]
fn with_handle<F, R>(mut f: F) -> R
where
    F: FnMut(&LocalHandle) -> R,
{
    HANDLE
        .try_with(|h| f(h))
        .unwrap_or_else(|_| f(&collector().register()))
}

#[cfg(test)]
include!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../../test/foundation/concurrent-collections/epoch/unit/src/default/all_tests_64.rs"));
