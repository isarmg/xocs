//! Declare symbol for `BindingIdentifier`s

use smallvec::SmallVec;

use oxc_allocator::{GetAddress, UnstableAddress};
use oxc_ast::{AstKind, ast::*};
use oxc_ecmascript::{BoundNames, IsSimpleParameterList};
use oxc_span::GetSpan;
use oxc_str::Ident;
use oxc_syntax::{node::NodeId, scope::ScopeFlags, scope::ScopeId, symbol::SymbolFlags};

use crate::{SemanticBuilder, checker::is_function_decl_part_of_if_statement};

pub trait Binder<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>);
}

impl<'a> Binder<'a> for VariableDeclarator<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let AstKind::VariableDeclaration(declaration) = builder.ancestry().parent_kind() else {
            unreachable!();
        };
        let kind = declaration.kind;
        let is_declare = declaration.declare;

        let (mut includes, excludes) = match kind {
            VariableDeclarationKind::Const
            | VariableDeclarationKind::Using
            | VariableDeclarationKind::AwaitUsing => (
                SymbolFlags::BlockScopedVariable | SymbolFlags::ConstVariable,
                SymbolFlags::BlockScopedVariableExcludes,
            ),
            VariableDeclarationKind::Let => {
                (SymbolFlags::BlockScopedVariable, SymbolFlags::BlockScopedVariableExcludes)
            }
            VariableDeclarationKind::Var => {
                (SymbolFlags::FunctionScopedVariable, SymbolFlags::FunctionScopedVariableExcludes)
            }
        };

        if is_declare {
            includes |= SymbolFlags::Ambient;
        }

        if kind.is_lexical() {
            self.id.bound_names(&mut |ident| {
                let symbol_id = builder.declare_symbol(ident.span, ident.name, includes, excludes);
                ident.symbol_id.set(Some(symbol_id));
            });
        } else {
            // ------------------ var hosting ------------------
            let mut target_scope_id = builder.current_scope_id;
            // Stack-allocated: nesting depth from a `var`/`let`/`const` to the
            // enclosing function (or program) scope is small in practice — 8
            // covers almost all real-world cases without heap allocation.
            let mut var_scope_ids: SmallVec<[ScopeId; 8]> = SmallVec::new();

            // Collect all scopes where variable hoisting can occur
            for scope_id in builder.scoping.scope_ancestors(target_scope_id) {
                let flags = builder.scoping.scope_flags(scope_id);
                if flags.is_var() {
                    target_scope_id = scope_id;
                    break;
                }
                var_scope_ids.push(scope_id);
            }

            self.id.bound_names(&mut |ident| {
                let span = ident.span;
                let name = ident.name;
                let mut declared_symbol_id = None;

                for &scope_id in &var_scope_ids {
                    if let Some(symbol_id) =
                        builder.check_redeclaration(scope_id, span, name, excludes)
                    {
                        builder.add_redeclare_variable(symbol_id, includes, span);
                        declared_symbol_id = Some(symbol_id);

                        // Hoist current symbol to target scope when it is not already declared
                        // in the target scope.
                        if !builder.scoping.scope_has_binding(target_scope_id, name) {
                            // remove current scope binding and add to target scope
                            // avoid same symbols appear in multi-scopes
                            builder.scoping.remove_binding(scope_id, name);
                            builder.scoping.add_binding(target_scope_id, name, symbol_id);
                            builder.scoping.set_symbol_scope_id(symbol_id, target_scope_id);
                        }
                        break;
                    }
                }

                // If a variable is already declared in the hoisted scopes,
                // we don't need to create another symbol with the same name
                // to make sure they point to the same symbol.
                let symbol_id = declared_symbol_id.unwrap_or_else(|| {
                    builder.declare_symbol_on_scope(span, name, target_scope_id, includes, excludes)
                });
                ident.symbol_id.set(Some(symbol_id));

                // Finally, add the variable to all hoisted scopes
                // to support redeclaration checks when declaring variables with the same name later.
                for &scope_id in &var_scope_ids {
                    builder.hoisting_variables.insert((scope_id, name), symbol_id);
                }
            });
        }

        // Save `@__NO_SIDE_EFFECTS__` for function initializers.
        if let BindingPattern::BindingIdentifier(id) = &self.id
            && let Some(symbol_id) = id.symbol_id.get()
            && let Some(init) = &self.init
            && match init {
                Expression::FunctionExpression(func) => func.pure,
                Expression::ArrowFunctionExpression(func) => func.pure,
                _ => false,
            }
        {
            builder.scoping.no_side_effects.insert(symbol_id);
        }
    }
}

impl<'a> Binder<'a> for Class<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let includes = if self.declare {
            SymbolFlags::Class | SymbolFlags::Ambient
        } else {
            SymbolFlags::Class
        };
        let Some(ident) = &self.id else { return };
        let symbol_id =
            builder.declare_symbol(ident.span, ident.name, includes, SymbolFlags::ClassExcludes);
        ident.symbol_id.set(Some(symbol_id));
    }
}

impl<'a> Binder<'a> for Function<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let is_declaration = self.is_declaration();

        if let Some(ident) = &self.id {
            let mut includes = SymbolFlags::Function;
            if self.declare {
                includes |= SymbolFlags::Ambient;
            }
            // A named function expression, so `check_redeclaration` can recognise its name binding
            // (e.g. `(function n(n) {})` - the parameter `n` is not a redeclaration of the name).
            if self.is_expression() {
                includes |= SymbolFlags::FunctionExpression;
            }
            // An `async`/generator function, so the Annex B.3.3 redeclaration check can tell plain
            // (relaxable) function declarations apart from these.
            if self.r#async || self.generator {
                includes |= SymbolFlags::AsyncOrGeneratorFunction;
            }

            let excludes = if builder.source_type.is_typescript() {
                SymbolFlags::FunctionExcludes
            } else if is_declaration && is_function_decl_part_of_if_statement(self, builder) {
                SymbolFlags::empty()
            } else {
                // `var x; function x() {}` is valid in non-strict mode, but `TypeScript`
                // doesn't care about non-strict mode, so we need to exclude this,
                // and further check in checker.
                SymbolFlags::FunctionExcludes - SymbolFlags::FunctionScopedVariable
            };

            let symbol_id = builder.declare_symbol(ident.span, ident.name, includes, excludes);
            ident.symbol_id.set(Some(symbol_id));

            let scope_flags = builder.current_scope_flags();

            // Annex B.3.2.1: In sloppy mode, plain function declarations inside block
            // scopes also create an implicit var-like binding in the enclosing function
            // scope. Hoist to the var scope — same pattern as var hoisting (line 46).
            if is_declaration // function expressions are bound in their own (var) scope
                && !self.r#async // Annex B only applies to plain functions
                && !self.generator // not generators or async generators
                && !builder.source_type.is_typescript() // Annex B is JavaScript-only
                && !scope_flags.is_var() // already in a var scope, no hoisting needed
                && !scope_flags.is_strict_mode()
            // no Annex B in strict mode / modules
            {
                let block_scope_id = builder.current_scope_id;
                let var_scope_id = builder
                    .scoping
                    .scope_ancestors(block_scope_id)
                    .skip(1)
                    .find(|&id| builder.scoping.scope_flags(id).is_var());
                if let Some(var_scope_id) = var_scope_id
                    && !builder.scoping.scope_has_binding(var_scope_id, ident.name)
                {
                    builder.scoping.move_binding_by_symbol_id(
                        block_scope_id,
                        var_scope_id,
                        symbol_id,
                    );
                    builder.hoisting_variables.insert((block_scope_id, ident.name), symbol_id);
                }
            }

            // Save `@__NO_SIDE_EFFECTS__`
            if self.pure {
                builder.scoping.no_side_effects.insert(symbol_id);
            }
        }

        // Bind scope flags: GetAccessor | SetAccessor
        if !is_declaration && let AstKind::ObjectProperty(prop) = builder.ancestry().parent_kind() {
            // Do not bind scope flags when function is inside of the object property key:
            //
            // { set [function() {}](val) {} }
            //        ^^^^^^^^^^^^^
            if prop.key.address() == self.unstable_address() {
                return;
            }
            let flags = builder.scoping.scope_flags_mut(builder.current_scope_id);
            match prop.kind {
                PropertyKind::Get => *flags |= ScopeFlags::GetAccessor,
                PropertyKind::Set => *flags |= ScopeFlags::SetAccessor,
                PropertyKind::Init => {}
            }
        }
    }
}

impl<'a> Binder<'a> for BindingRestElement<'a> {
    // Binds the FormalParameters's rest of a function or method.
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let parent_kind = builder.ancestry().parent_kind();
        let AstKind::FormalParameters(_) = parent_kind else {
            return;
        };

        let includes = SymbolFlags::FunctionScopedVariable;
        let excludes =
            SymbolFlags::FunctionScopedVariable | SymbolFlags::FunctionScopedVariableExcludes;
        self.bound_names(&mut |ident| {
            let symbol_id = builder.declare_symbol(ident.span, ident.name, includes, excludes);
            ident.symbol_id.set(Some(symbol_id));
        });
    }
}

impl<'a> Binder<'a> for FormalParameter<'a> {
    // Binds the FormalParameter of a function or method.
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let parent_kind = builder.ancestry().parent_kind();
        let AstKind::FormalParameters(parameters) = parent_kind else { unreachable!() };

        let includes = SymbolFlags::FunctionScopedVariable;

        let is_not_allowed_duplicate_parameters = matches!(
                parameters.kind,
                // ArrowFormalParameters: UniqueFormalParameters
                FormalParameterKind::ArrowFormalParameters |
                // UniqueFormalParameters : FormalParameters
                // * It is a Syntax Error if BoundNames of FormalParameters contains any duplicate elements.
                FormalParameterKind::UniqueFormalParameters
            ) ||
            // Multiple occurrences of the same BindingIdentifier in a FormalParameterList is only allowed for functions which have simple parameter lists and which are not defined in strict mode code.
            builder.strict_mode() ||
            // FormalParameters : FormalParameterList
            // * It is a Syntax Error if IsSimpleParameterList of FormalParameterList is false and BoundNames of FormalParameterList contains any duplicate elements.
            !parameters.is_simple_parameter_list();

        let excludes = if is_not_allowed_duplicate_parameters {
            SymbolFlags::FunctionScopedVariable | SymbolFlags::FunctionScopedVariableExcludes
        } else {
            SymbolFlags::FunctionScopedVariableExcludes
        };

        self.bound_names(&mut |ident| {
            let symbol_id = builder.declare_symbol(ident.span, ident.name, includes, excludes);
            ident.symbol_id.set(Some(symbol_id));
        });
    }
}

impl<'a> Binder<'a> for FormalParameterRest<'a> {
    // Binds the FormalParameter of a function or method.
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let parent_kind = builder.ancestry().parent_kind();
        let AstKind::FormalParameters(parameters) = parent_kind else { unreachable!() };

        let includes = SymbolFlags::FunctionScopedVariable;

        let is_not_allowed_duplicate_parameters = matches!(
                parameters.kind,
                // ArrowFormalParameters: UniqueFormalParameters
                FormalParameterKind::ArrowFormalParameters |
                // UniqueFormalParameters : FormalParameters
                // * It is a Syntax Error if BoundNames of FormalParameters contains any duplicate elements.
                FormalParameterKind::UniqueFormalParameters
            ) ||
            // Multiple occurrences of the same BindingIdentifier in a FormalParameterList is only allowed for functions which have simple parameter lists and which are not defined in strict mode code.
            builder.strict_mode() ||
            // FormalParameters : FormalParameterList
            // * It is a Syntax Error if IsSimpleParameterList of FormalParameterList is false and BoundNames of FormalParameterList contains any duplicate elements.
            !parameters.is_simple_parameter_list();

        let excludes = if is_not_allowed_duplicate_parameters {
            SymbolFlags::FunctionScopedVariable | SymbolFlags::FunctionScopedVariableExcludes
        } else {
            SymbolFlags::FunctionScopedVariableExcludes
        };

        self.rest.argument.bound_names(&mut |ident| {
            let symbol_id = builder.declare_symbol(ident.span, ident.name, includes, excludes);
            ident.symbol_id.set(Some(symbol_id));
        });
    }
}

impl<'a> Binder<'a> for CatchParameter<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let current_scope_id = builder.current_scope_id;
        // https://tc39.es/ecma262/#sec-variablestatements-in-catch-blocks
        // It is a Syntax Error if any element of the BoundNames of CatchParameter also occurs in the VarDeclaredNames of Block
        // unless CatchParameter is CatchParameter : BindingIdentifier
        if let BindingPattern::BindingIdentifier(ident) = &self.pattern {
            let includes = SymbolFlags::FunctionScopedVariable | SymbolFlags::CatchVariable;
            let symbol_id =
                builder.declare_shadow_symbol(ident.name, ident.span, current_scope_id, includes);
            ident.symbol_id.set(Some(symbol_id));
        } else {
            self.pattern.bound_names(&mut |ident| {
                let symbol_id = builder.declare_symbol(
                    ident.span,
                    ident.name,
                    SymbolFlags::BlockScopedVariable | SymbolFlags::CatchVariable,
                    SymbolFlags::BlockScopedVariableExcludes,
                );
                ident.symbol_id.set(Some(symbol_id));
            });
        }
    }
}

fn declare_symbol_for_import_specifier<'a>(
    ident: &BindingIdentifier<'a>,
    is_type: bool,
    builder: &mut SemanticBuilder<'a>,
) {
    let includes = if is_type
        || matches!(builder.ancestry().parent_kind(), AstKind::ImportDeclaration(decl) if decl.import_kind.is_type(),
        ) {
        SymbolFlags::TypeImport
    } else {
        SymbolFlags::Import
    };

    let symbol_id = builder.declare_symbol(
        ident.span,
        ident.name,
        includes,
        SymbolFlags::ImportBindingExcludes,
    );
    ident.symbol_id.set(Some(symbol_id));
}

impl<'a> Binder<'a> for ImportSpecifier<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        declare_symbol_for_import_specifier(&self.local, self.import_kind.is_type(), builder);
    }
}

impl<'a> Binder<'a> for ImportDefaultSpecifier<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        declare_symbol_for_import_specifier(&self.local, false, builder);
    }
}

impl<'a> Binder<'a> for ImportNamespaceSpecifier<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        declare_symbol_for_import_specifier(&self.local, false, builder);
    }
}

impl<'a> Binder<'a> for TSImportEqualsDeclaration<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        declare_symbol_for_import_specifier(&self.id, false, builder);
    }
}

impl<'a> Binder<'a> for TSTypeAliasDeclaration<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let includes = if self.declare {
            SymbolFlags::TypeAlias | SymbolFlags::Ambient
        } else {
            SymbolFlags::TypeAlias
        };
        let symbol_id = builder.declare_symbol(
            self.id.span,
            self.id.name,
            includes,
            SymbolFlags::TypeAliasExcludes,
        );
        self.id.symbol_id.set(Some(symbol_id));
    }
}

impl<'a> Binder<'a> for TSInterfaceDeclaration<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let includes = if self.declare {
            SymbolFlags::Interface | SymbolFlags::Ambient
        } else {
            SymbolFlags::Interface
        };
        let symbol_id = builder.declare_symbol(
            self.id.span,
            self.id.name,
            includes,
            SymbolFlags::InterfaceExcludes,
        );
        self.id.symbol_id.set(Some(symbol_id));
    }
}

impl<'a> Binder<'a> for TSEnumDeclaration<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let is_const = self.r#const;
        let includes = if self.declare { SymbolFlags::Ambient } else { SymbolFlags::empty() };
        let (includes, excludes) = if is_const {
            (SymbolFlags::ConstEnum | includes, SymbolFlags::ConstEnumExcludes)
        } else {
            (SymbolFlags::RegularEnum | includes, SymbolFlags::RegularEnumExcludes)
        };
        let symbol_id = builder.declare_symbol(self.id.span, self.id.name, includes, excludes);
        self.id.symbol_id.set(Some(symbol_id));
    }
}

impl<'a> Binder<'a> for TSEnumMember<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        // Extract Ident directly from Identifier variant to preserve precomputed hash.
        let name = match &self.id {
            TSEnumMemberName::Identifier(ident) => ident.name,
            _ => Ident::from(self.id.static_name()),
        };
        builder.declare_symbol(
            self.id.span(),
            name,
            SymbolFlags::EnumMember,
            SymbolFlags::EnumMemberExcludes,
        );
    }
}

impl<'a> Binder<'a> for TSNamespaceDeclaration<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let id = &self.id;
        let instantiated =
            get_module_instance_state(builder, self, builder.node_store.current_node_id)
                .is_instantiated();
        let (mut includes, excludes) = if instantiated {
            (SymbolFlags::ValueModule, SymbolFlags::ValueModuleExcludes)
        } else {
            (SymbolFlags::NamespaceModule, SymbolFlags::NamespaceModuleExcludes)
        };

        if self.declare {
            includes |= SymbolFlags::Ambient;
        }
        let symbol_id = builder.declare_symbol(id.span, id.name, includes, excludes);

        id.set_symbol_id(symbol_id);
    }
}

#[derive(PartialEq, Eq, Debug, Clone, Copy)]
pub enum ModuleInstanceState {
    NonInstantiated,
    Instantiated,
    ConstEnumOnly,
}

impl ModuleInstanceState {
    fn is_instantiated(self) -> bool {
        self != ModuleInstanceState::NonInstantiated
    }
}

/// Determines if a module is instantiated or not.
///
/// Based on `https://github.com/microsoft/TypeScript/blob/15392346d05045742e653eab5c87538ff2a3c863/src/compiler/binder.ts#L342-L474`
fn get_module_instance_state<'a>(
    builder: &mut SemanticBuilder<'a>,
    decl: &TSNamespaceDeclaration<'a>,
    current_node_id: NodeId,
) -> ModuleInstanceState {
    get_module_instance_state_impl(builder, decl, current_node_id, &mut Vec::new())
}

fn get_module_instance_state_impl<'a, 'b>(
    builder: &mut SemanticBuilder<'a>,
    decl: &'b TSNamespaceDeclaration<'a>,
    current_node_id: NodeId,
    module_declaration_stmts: &mut Vec<&'b Statement<'a>>,
) -> ModuleInstanceState {
    // `SemanticBuilder` takes an immutable reference to AST, so `unstable_address` produces stable `Address`es
    let address = decl.unstable_address();

    if let Some(state) = builder.module_instance_state_cache.get(&address) {
        return *state;
    }

    // A module is uninstantiated if it contains only specific declarations
    let state = match &decl.body {
        TSNamespaceDeclarationBody::TSModuleBlock(block) => {
            module_declaration_stmts.extend(block.body.iter());

            let mut child_state = ModuleInstanceState::NonInstantiated;
            for stmt in &block.body {
                child_state = get_module_instance_state_for_statement(
                    builder,
                    stmt,
                    current_node_id,
                    module_declaration_stmts,
                );
                if child_state.is_instantiated() {
                    break;
                }
            }
            child_state
        }
        TSNamespaceDeclarationBody::TSNamespaceDeclaration(namespace) => {
            get_module_instance_state(builder, namespace, current_node_id)
        }
    };

    builder.module_instance_state_cache.insert(address, state);
    state
}

fn get_external_module_instance_state_impl<'a, 'b>(
    builder: &mut SemanticBuilder<'a>,
    decl: &'b TSExternalModuleDeclaration<'a>,
    current_node_id: NodeId,
    module_declaration_stmts: &mut Vec<&'b Statement<'a>>,
) -> ModuleInstanceState {
    let address = decl.unstable_address();

    if let Some(state) = builder.module_instance_state_cache.get(&address) {
        return *state;
    }

    let Some(block) = &decl.body else {
        return ModuleInstanceState::Instantiated;
    };

    module_declaration_stmts.extend(block.body.iter());
    let mut state = ModuleInstanceState::NonInstantiated;
    for stmt in &block.body {
        state = get_module_instance_state_for_statement(
            builder,
            stmt,
            current_node_id,
            module_declaration_stmts,
        );
        if state.is_instantiated() {
            break;
        }
    }

    builder.module_instance_state_cache.insert(address, state);
    state
}

fn get_module_instance_state_for_statement<'a, 'b>(
    builder: &mut SemanticBuilder<'a>,
    stmt: &'b Statement<'a>,
    current_node_id: NodeId,
    module_declaration_stmts: &mut Vec<&'b Statement<'a>>,
) -> ModuleInstanceState {
    let address = stmt.address();
    if let Some(state) = builder.module_instance_state_cache.get(&address) {
        return *state;
    }

    let state = match stmt {
            // 1. interface declarations, type alias declarations
            Statement::TSInterfaceDeclaration(_)
            | Statement::TSTypeAliasDeclaration(_)
            // 3. non-exported import declarations
            | Statement::TSImportEqualsDeclaration(_) => {
                ModuleInstanceState::NonInstantiated
            }
            // 2. const enum declarations
            Statement::TSEnumDeclaration(enum_decl) => {
                if enum_decl.r#const {
                    ModuleInstanceState::ConstEnumOnly
                } else {
                    ModuleInstanceState::Instantiated
                }
            }
            Statement::ExportDefaultDeclaration(export_decl)  => {
                if matches!(export_decl.declaration, ExportDefaultDeclarationKind::TSInterfaceDeclaration(_)) {
                    ModuleInstanceState::NonInstantiated
                } else {
                    ModuleInstanceState::Instantiated
                }
            }
            Statement::ExportDeclaration(export_decl) => {
                match &export_decl.declaration {
                    Declaration::TSExternalModuleDeclaration(module_decl) => {
                        get_external_module_instance_state_impl(builder, module_decl, current_node_id, module_declaration_stmts)
                    }
                    Declaration::TSNamespaceDeclaration(namespace_decl) => {
                        get_module_instance_state_impl(builder, namespace_decl, current_node_id, module_declaration_stmts)
                    }
                    decl => if decl.is_type() {
                        ModuleInstanceState::NonInstantiated
                    } else {
                        ModuleInstanceState::Instantiated
                    }
                }
            }
            // 4. Export alias declarations pointing at uninstantiated modules
            Statement::ExportNamedDeclaration(export_decl) => {
                let mut export_state = ModuleInstanceState::NonInstantiated;
                for specifier in &export_decl.specifiers {
                    export_state = get_module_instance_state_for_alias_target(builder, specifier, current_node_id, module_declaration_stmts.as_slice());
                    if export_state.is_instantiated() {
                        break;
                    }
                }
                export_state
            }
            // 5. other module declarations
            Statement::TSNamespaceDeclaration(namespace_decl) => {
                get_module_instance_state_impl(builder, namespace_decl, current_node_id, module_declaration_stmts)
            }
            Statement::TSExternalModuleDeclaration(module_decl) => {
                get_external_module_instance_state_impl(builder, module_decl, current_node_id, module_declaration_stmts)
            }
            // Any other type of statement means the module is instantiated
            _ => ModuleInstanceState::Instantiated,
        };

    builder.module_instance_state_cache.insert(address, state);
    state
}

// `module_declaration_stmts` is stored statements that are collected from the all ModuleBlocks.
// The reason we need to collect and pass in this method is that we need to check export specifiers
// whether they refer to a declaration that declared in the module block or not. And we can't use
// `self.nodes.node(node_id)` to get the nested module block's statements since the child ModuleBlock
// AstNode hasn't created yet.
fn get_module_instance_state_for_alias_target<'a>(
    builder: &mut SemanticBuilder<'a>,
    specifier: &ExportSpecifier<'a>,
    mut current_node_id: NodeId,
    module_declaration_stmts: &[&Statement<'a>],
) -> ModuleInstanceState {
    let ModuleExportName::IdentifierReference(local) = &specifier.local else {
        return ModuleInstanceState::Instantiated;
    };

    let name = local.name;
    let mut current_block_stmts = module_declaration_stmts.to_vec();
    loop {
        let mut found = false;
        for stmt in &current_block_stmts {
            match stmt {
                Statement::VariableDeclaration(decl) => {
                    decl.bound_names(&mut |id| {
                        if id.name == name {
                            found = true;
                        }
                    });
                }
                match_declaration!(Statement) => {
                    if stmt.to_declaration().id().is_some_and(|id| id.name == name) {
                        found = true;
                    }
                }
                Statement::ExportDeclaration(decl) => match &decl.declaration {
                    Declaration::VariableDeclaration(decl) => {
                        decl.bound_names(&mut |id| {
                            if id.name == name {
                                found = true;
                            }
                        });
                    }
                    decl => {
                        if decl.id().is_some_and(|id| id.name == name) {
                            found = true;
                        }
                    }
                },
                Statement::ExportDefaultDeclaration(decl) => match &decl.declaration {
                    ExportDefaultDeclarationKind::FunctionDeclaration(decl)
                        if decl.id.as_ref().is_some_and(|id| id.name == name) =>
                    {
                        found = true;
                    }
                    ExportDefaultDeclarationKind::ClassDeclaration(decl)
                        if decl.id.as_ref().is_some_and(|id| id.name == name) =>
                    {
                        found = true;
                    }
                    ExportDefaultDeclarationKind::TSInterfaceDeclaration(decl)
                        if decl.id.name == name =>
                    {
                        found = true;
                    }
                    _ => {}
                },
                _ => {}
            }

            if found {
                if matches!(stmt, Statement::TSImportEqualsDeclaration(_)) {
                    // Treat re-exports of import aliases as instantiated,
                    // since they're ambiguous. This is consistent with
                    // `export import x = mod.x` being treated as instantiated:
                    //   import x = mod.x;
                    //   export { x };
                    return ModuleInstanceState::Instantiated;
                }
                return get_module_instance_state_for_statement(
                    builder,
                    stmt,
                    current_node_id,
                    &mut Vec::default(), // No need to check export specifier
                );
            }
        }

        // Walk up the ancestry stack (excluding `current_node_id` itself) to the
        // nearest enclosing block-like node.
        let Some(kind) =
            builder.ancestry().ancestor_kinds_from(Some(current_node_id)).skip(1).find(|kind| {
                matches!(
                    kind,
                    AstKind::Program(_) | AstKind::TSModuleBlock(_) | AstKind::BlockStatement(_)
                )
            })
        else {
            break;
        };

        current_node_id = kind.node_id();
        current_block_stmts.clear();
        // Didn't find the declaration whose name matches export specifier
        // in the current block, so we need to check the parent block.
        current_block_stmts.extend(match kind {
            AstKind::Program(program) => program.body.iter(),
            AstKind::TSModuleBlock(block) => block.body.iter(),
            AstKind::BlockStatement(block) => block.body.iter(),
            _ => unreachable!(),
        });
    }

    // Not found in any of the statements
    ModuleInstanceState::Instantiated
}

impl<'a> Binder<'a> for TSTypeParameter<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let scope_id = if matches!(builder.ancestry().parent_kind(), AstKind::TSInferType(_)) {
            builder
                .scoping
                .scope_ancestors(builder.current_scope_id)
                .find(|scope_id| builder.scoping.scope_flags(*scope_id).is_ts_conditional())
        } else {
            None
        };

        let symbol_id = builder.declare_symbol_on_scope(
            self.name.span,
            self.name.name,
            scope_id.unwrap_or(builder.current_scope_id),
            SymbolFlags::TypeParameter,
            SymbolFlags::TypeParameterExcludes,
        );
        self.name.symbol_id.set(Some(symbol_id));
    }
}

impl<'a> Binder<'a> for TSMappedType<'a> {
    fn bind(&self, builder: &mut SemanticBuilder<'a>) {
        let symbol_id = builder.declare_symbol_on_scope(
            self.key.span,
            self.key.name,
            builder.current_scope_id,
            SymbolFlags::TypeParameter,
            SymbolFlags::TypeParameterExcludes,
        );
        self.key.symbol_id.set(Some(symbol_id));
    }
}
