use std::iter;

use crate::generated::ancestor::Ancestor;
use oxc_allocator::{ArenaBox, ArenaHashMap, ArenaVec, CloneIn, GetAllocator, TakeIn};
use oxc_ast::ast::*;
use oxc_ast_visit::{VisitJs, walk_js};
use oxc_compat::ESFeature;
use oxc_ecmascript::{
    constant_evaluation::{ConstantEvaluation, DetermineValueType, IsLiteralValue, ValueType},
    side_effects::MayHaveSideEffects,
};
use oxc_semantic::ScopeFlags;
use oxc_span::{ContentEq, GetSpan, GetSpanMut, SPAN};
use oxc_syntax::symbol::SymbolId;

use crate::{TraverseCtx, is_terminated::IsTerminated, keep_var::KeepVar};

use super::PeepholeOptimizations;

type StatementIter<'a> = <ArenaVec<'a, Statement<'a>> as IntoIterator>::IntoIter;

/// `false` when dropping `stmt` produces a byte-identical AST — a `var`
/// with no initializers, which `KeepVar` re-emits unchanged at the end of
/// the block. Flagging such an identity drop as a real change would
/// oscillate the peephole fixed-point loop forever.
///
/// A TS type annotation disqualifies the identity classification: `KeepVar`'s
/// re-emit strips annotations, and an annotation can hold resolved references
/// (computed keys in a type literal) that must go through the drop walk.
fn dead_drop_mutates_ast(stmt: &Statement<'_>) -> bool {
    !matches!(stmt, Statement::VariableDeclaration(decl)
        if decl.kind.is_var()
            && decl.declarations.iter().all(|d| d.init.is_none() && d.type_annotation.is_none()))
}

impl<'a> PeepholeOptimizations {
    /// `mangleStmts`: <https://github.com/evanw/esbuild/blob/v0.24.2/internal/js_ast/js_parser.go#L8788>
    ///
    /// See also
    ///
    /// ## Statement Fusion
    /// <https://github.com/google/closure-compiler/blob/v20240609/src/com/google/javascript/jscomp/StatementFusion.java>
    ///
    /// ## Collapse variable declarations
    /// `var a; var b = 1; var c = 2` => `var a, b = 1; c = 2`
    /// <https://github.com/google/closure-compiler/blob/v20240609/src/com/google/javascript/jscomp/CollapseVariableDeclarations.java>
    ///
    /// ## Collapse into for statements:
    /// `var a = 0; for(;a<0;a++) {}` => `for(var a = 0;a<0;a++) {}`
    /// <https://github.com/google/closure-compiler/blob/v20240609/src/com/google/javascript/jscomp/Denormalize.java>
    ///
    /// ## MinimizeExitPoints:
    /// <https://github.com/google/closure-compiler/blob/v20240609/src/com/google/javascript/jscomp/MinimizeExitPoints.java>
    pub fn minimize_statements(stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a>) {
        let mut new_stmts = ArenaVec::with_capacity_in(stmts.len(), ctx);
        let mut old_stmts = stmts.take_in(ctx).into_iter();
        let mut is_control_flow_dead = false;
        let mut keep_var = KeepVar::new();
        let mut identity_drops = 0u32;
        while let Some(stmt) = old_stmts.next() {
            if is_control_flow_dead
                && !stmt.is_module_declaration()
                && !matches!(stmt.as_declaration(), Some(Declaration::FunctionDeclaration(_)))
            {
                // Harvest any `var` bindings so they re-emit at the end of
                // the block (see `keep_var.get_variable_declaration_statement`
                // below).
                keep_var.visit_statement(&stmt);
                // Re-flag the peephole loop so the next iteration runs with
                // refreshed reference counts and the unused-declarator pass
                // can remove bindings that this drop just orphaned (e.g.
                // `var x = {}` after dropping `module.exports = x;`).
                if dead_drop_mutates_ast(&stmt) {
                    ctx.drop_statement(&stmt);
                } else {
                    identity_drops += 1;
                }
                continue; // drop: `stmt` is intentionally not pushed into `new_stmts`.
            }
            Self::minimize_statement(stmt, &mut old_stmts, &mut new_stmts, ctx);
            // A statement that never completes normally — a direct jump, a
            // kept block ending in a jump, an if/else or try/catch where
            // every branch jumps — makes the rest of the list unreachable.
            // https://github.com/rolldown/rolldown/issues/10184
            if !is_control_flow_dead
                && !old_stmts.as_slice().is_empty()
                && new_stmts.last().is_some_and(Statement::is_terminated)
            {
                is_control_flow_dead = true;
            }
        }
        if let Some(stmt) = keep_var.get_variable_declaration_statement(&ctx.ast) {
            match Self::remove_unused_variable_declaration(stmt, ctx) {
                // Multiple identity-dropped `var x;`s coalesce into a single
                // `var x, y;`. The individual drops looked byte-identical, but
                // the combined re-emit is a real AST change — re-flag so the
                // fixed-point loop doesn't terminate one iteration early.
                Some(stmt) => {
                    new_stmts.push(stmt);
                    if identity_drops > 1 {
                        ctx.notice_change();
                    }
                }
                // The harvested `var` was entirely unused; the net effect of
                // drop + re-hoist + remove is removing the declaration, even
                // though every individual drop was classified as identity.
                None => ctx.notice_change(),
            }
        }

        // Drop a trailing unconditional jump statement if applicable
        if let Some(last_stmt) = new_stmts.last()
            && Self::can_remove_termination_statement(last_stmt, ctx)
        {
            let dropped = new_stmts.pop().unwrap();
            ctx.drop_statement(&dropped);
        }
        *stmts = new_stmts;
    }

    /// Some parsers cannot parse long conditional expressions.
    /// See <https://bugzilla.mozilla.org/show_bug.cgi?id=2033215>
    fn conditional_expression_count_exceeded(expr: &Expression<'a>) -> bool {
        let mut depth = 0u16;
        let mut current = expr;
        while let Expression::ConditionalExpression(c) = current {
            depth += 1;
            if depth == 500 {
                return true;
            }
            current = &c.alternate;
        }
        false
    }

    /// Check whether two import declarations can be merged.
    fn can_merge_imports(first: &ImportDeclaration<'a>, second: &ImportDeclaration<'a>) -> bool {
        if first.source.value != second.source.value
            || first.phase != second.phase
            || first.phase == Some(ImportPhase::Source)
            || first.import_kind != second.import_kind
            || first.import_kind.is_type()
            || first.with_clause.content_ne(&second.with_clause)
        {
            return false;
        }

        // Additional default specifiers can be represented as named imports of
        // `default`. Namespace and named specifiers cannot coexist.
        let mut default_count = 0;
        let mut has_namespace = false;
        let mut has_named = false;
        for specifier in first
            .specifiers
            .iter()
            .flat_map(|specifiers| specifiers.iter())
            .chain(second.specifiers.iter().flat_map(|specifiers| specifiers.iter()))
        {
            match specifier {
                ImportDeclarationSpecifier::ImportSpecifier(_) => has_named = true,
                ImportDeclarationSpecifier::ImportDefaultSpecifier(_) => default_count += 1,
                ImportDeclarationSpecifier::ImportNamespaceSpecifier(_) => {
                    if has_namespace {
                        return false;
                    }
                    has_namespace = true;
                }
            }
        }
        !(has_namespace && (has_named || default_count > 1))
    }

    /// Convert a default import into a named import of the module's `default`
    /// export. This allows multiple default bindings in one import clause.
    fn default_to_named_import(
        default_specifier: ImportDeclarationSpecifier<'a>,
        ctx: &TraverseCtx<'a>,
    ) -> ImportDeclarationSpecifier<'a> {
        let ImportDeclarationSpecifier::ImportDefaultSpecifier(default_specifier) =
            default_specifier
        else {
            unreachable!();
        };
        let ImportDefaultSpecifier { span, local, .. } = default_specifier.unbox();
        ImportDeclarationSpecifier::new_import_specifier(
            span,
            ModuleExportName::IdentifierName(IdentifierName::new(span, "default", ctx)),
            local,
            ImportOrExportKind::Value,
            ctx,
        )
    }

    /// Merge import declarations that load the same module request.
    ///
    /// ```js
    /// import { foo } from "module";
    /// import { bar } from "other";
    /// import { baz } from "module";
    /// // becomes
    /// import { foo, baz } from "module";
    /// import { bar } from "other";
    /// ```
    pub fn merge_imports(stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a>) {
        let mut import_cache: ArenaHashMap<'a, &'a str, ArenaVec<'a, usize>> =
            ArenaHashMap::new_in(ctx.allocator());
        let mut merges = ArenaVec::new_in(ctx);

        // Merge into the target immediately so later declarations are checked
        // against the combined import clause. Keep every unmerged declaration
        // in a source group because import attributes, phases, and type/value
        // mode may differ between declarations with the same source string.
        for statement_index in 0..stmts.len() {
            let Statement::ImportDeclaration(import_decl) = stmts.get(statement_index).unwrap()
            else {
                continue;
            };
            let candidates = import_cache
                .entry(import_decl.source.value.as_str())
                .or_insert_with(|| ArenaVec::new_in(ctx));
            let target_index = candidates.iter().find_map(|&target_index| {
                let Some(Statement::ImportDeclaration(target)) = stmts.get(target_index) else {
                    return None;
                };
                Self::can_merge_imports(target, import_decl).then_some(target_index)
            });

            let Some(target_index) = target_index else {
                candidates.push(statement_index);
                continue;
            };

            {
                let source_stmt = stmts.get(statement_index).unwrap();
                ctx.drop_statement(source_stmt);
            }
            let Statement::ImportDeclaration(source_import) =
                stmts.get_mut(statement_index).unwrap()
            else {
                unreachable!();
            };
            let Some(mut source_specifiers) = source_import.specifiers.take() else {
                merges.push(statement_index);
                continue;
            };

            let Statement::ImportDeclaration(target_import) = stmts.get_mut(target_index).unwrap()
            else {
                unreachable!();
            };
            // default must be first specifier in import
            let is_default_specifier = |s: &ImportDeclarationSpecifier| {
                matches!(s, ImportDeclarationSpecifier::ImportDefaultSpecifier(_))
            };
            if let Some(target_specifiers) = &mut target_import.specifiers {
                if source_specifiers.first().is_some_and(is_default_specifier) {
                    let default_specifier = source_specifiers.remove(0);
                    if target_specifiers.first().is_some_and(is_default_specifier) {
                        target_specifiers
                            .push(Self::default_to_named_import(default_specifier, ctx));
                    } else {
                        target_specifiers.insert(0, default_specifier);
                    }
                }
                target_specifiers.append(&mut source_specifiers);
            } else {
                target_import.specifiers = Some(source_specifiers);
            }
            merges.push(statement_index);
        }

        // Remove imports in reverse order so removing a later import does not
        // shift the indices of any merge that is still waiting to be applied.
        for &source_index in merges.iter().rev() {
            stmts.remove(source_index);
        }
    }

    /// Check whether an import can be merged with a local named export.
    fn can_merge_import_export(
        import_decl: &ImportDeclaration<'a>,
        export_decl: &ExportNamedDeclaration<'a>,
        ctx: &TraverseCtx<'a>,
    ) -> bool {
        let Some(import_specifiers) = import_decl.specifiers.as_ref() else { return false };
        let is_namespace_import = matches!(
            import_specifiers.as_slice(),
            [ImportDeclarationSpecifier::ImportNamespaceSpecifier(_)]
        );

        if import_decl.phase.is_some()
            || import_decl.import_kind.is_type()
            || export_decl.export_kind.is_type()
            || import_specifiers.is_empty()
            || import_specifiers.len() > export_decl.specifiers.len()
            || (is_namespace_import && !ctx.supports_feature(ESFeature::ES2020ExportNamespaceFrom))
            || (is_namespace_import && export_decl.specifiers.len() != 1)
            || ctx.scoping().root_scope_flags().contains_direct_eval()
            || (!is_namespace_import
                && !import_specifiers.iter().all(|specifier| match specifier {
                    ImportDeclarationSpecifier::ImportSpecifier(specifier) => {
                        !specifier.import_kind.is_type()
                    }
                    ImportDeclarationSpecifier::ImportDefaultSpecifier(_) => true,
                    ImportDeclarationSpecifier::ImportNamespaceSpecifier(_) => false,
                }))
        {
            return false;
        }

        // Every local export must refer to one of the imported bindings, and
        // every imported binding must be used exactly by this export.
        for import_specifier in import_specifiers {
            let symbol_id = import_specifier.symbol_id();
            let export_count = export_decl
                .specifiers
                .iter()
                .filter(|export_specifier| {
                    let ModuleExportName::IdentifierReference(id) = &export_specifier.local else {
                        return false;
                    };
                    ctx.scoping().get_reference(id.reference_id()).symbol_id() == Some(symbol_id)
                })
                .count();
            if export_count == 0
                || ctx.scoping().get_resolved_reference_ids(symbol_id).len() != export_count
            {
                return false;
            }
        }

        export_decl.specifiers.iter().all(|export_specifier| {
            if export_specifier.export_kind.is_type() {
                return false;
            }
            let ModuleExportName::IdentifierReference(id) = &export_specifier.local else {
                return false;
            };
            let Some(symbol_id) = ctx.scoping().get_reference(id.reference_id()).symbol_id() else {
                return false;
            };
            import_specifiers
                .iter()
                .any(|import_specifier| import_specifier.symbol_id() == symbol_id)
        })
    }

    /// Merge an import and a local named export into a direct
    /// re-export.
    ///
    /// ```js
    /// import { foo as bar } from "module";
    /// export { bar as baz };
    /// // becomes
    /// export { foo as baz } from "module";
    ///
    /// import * as namespace from "module";
    /// export { namespace };
    /// // becomes
    /// export * as namespace from "module";
    ///
    /// import defaultExport from "module";
    /// export { defaultExport };
    /// // becomes
    /// export { default as defaultExport } from "module";
    /// ```
    ///
    /// The import declaration can only be removed when all of its bindings are
    /// represented by the export and have no other references. This also keeps
    /// direct `eval` from observing a binding that is removed here.
    pub fn merge_import_export(stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a>) {
        let mut import_export_cache: ArenaHashMap<'a, SymbolId, usize> =
            ArenaHashMap::new_in(ctx.allocator());
        let mut merges = ArenaVec::new_in(ctx);

        // Collect the candidates
        for (statement_index, stmt) in stmts.iter().enumerate() {
            match stmt {
                Statement::ImportDeclaration(import_decl) => {
                    if let Some(specifiers) = import_decl.specifiers.as_ref() {
                        import_export_cache.extend(
                            specifiers
                                .iter()
                                .map(|specifier| (specifier.symbol_id(), statement_index)),
                        );
                    }
                }
                Statement::ExportNamedDeclaration(export_decl) => {
                    let Some(import_index) = export_decl.specifiers.iter().find_map(|spec| {
                        let ModuleExportName::IdentifierReference(id) = &spec.local else {
                            return None;
                        };
                        let Some(symbol_id) =
                            ctx.scoping().get_reference(id.reference_id()).symbol_id()
                        else {
                            return None;
                        };
                        import_export_cache.get(&symbol_id).copied()
                    }) else {
                        continue;
                    };
                    let Some(Statement::ImportDeclaration(import_decl)) = stmts.get(import_index)
                    else {
                        continue;
                    };
                    if !Self::can_merge_import_export(import_decl, export_decl, ctx) {
                        continue;
                    }

                    merges.push((import_index, statement_index));
                    if let Some(specifiers) = import_decl.specifiers.as_ref() {
                        for specifier in specifiers {
                            let symbol_id = specifier.symbol_id();
                            if import_export_cache.get(&symbol_id) == Some(&import_index) {
                                import_export_cache.remove(&symbol_id);
                            }
                        }
                    }
                }
                _ => {}
            }
        }

        // Apply in reverse order so removing an export does not shift the
        // indices of any merge that is still waiting to be applied.
        for &(import_index, export_index) in merges.iter().rev() {
            // The old export contains references to the local import binding.
            // Mark those references before replacing them with the imported
            // module name.
            let old_export = stmts.remove(export_index);
            ctx.drop_statement(&old_export);
            let Statement::ExportNamedDeclaration(mut export_decl) = old_export else {
                unreachable!();
            };
            ctx.replace_statement_with(stmts.get_mut(import_index).unwrap(), |old_import, ctx| {
                ctx.drop_statement(&old_import);

                let Statement::ImportDeclaration(import_decl) = old_import else {
                    unreachable!();
                };
                let ImportDeclaration {
                    specifiers: Some(mut import_specifiers),
                    source,
                    with_clause,
                    ..
                } = import_decl.unbox()
                else {
                    unreachable!();
                };

                let is_namespace_import = matches!(
                    import_specifiers.as_slice(),
                    [ImportDeclarationSpecifier::ImportNamespaceSpecifier(_)]
                );
                if is_namespace_import {
                    let exported = export_decl.specifiers.pop().unwrap().exported;
                    return Statement::new_export_all_declaration(
                        export_decl.span,
                        Some(exported),
                        source,
                        with_clause,
                        export_decl.export_kind,
                        ctx,
                    );
                }

                for export_specifier in &mut export_decl.specifiers {
                    let ModuleExportName::IdentifierReference(id) = &export_specifier.local else {
                        unreachable!();
                    };
                    let symbol_id =
                        ctx.scoping().get_reference(id.reference_id()).symbol_id().unwrap();
                    let import_specifier = import_specifiers
                        .iter_mut()
                        .find(|import_specifier| import_specifier.symbol_id() == symbol_id)
                        .unwrap();
                    export_specifier.local = match import_specifier {
                        ImportDeclarationSpecifier::ImportSpecifier(import_specifier) => {
                            import_specifier.imported.clone_in(ctx.allocator())
                        }
                        ImportDeclarationSpecifier::ImportDefaultSpecifier(import_default) => {
                            ModuleExportName::IdentifierName(IdentifierName::new(
                                import_default.span,
                                "default",
                                ctx,
                            ))
                        }
                        ImportDeclarationSpecifier::ImportNamespaceSpecifier(_) => unreachable!(),
                    };
                }

                let export_decl = export_decl.unbox();
                Statement::new_export_from_declaration(
                    export_decl.span,
                    export_decl.specifiers,
                    source,
                    export_decl.export_kind,
                    with_clause,
                    ctx,
                )
            });
        }
    }

    fn minimize_statement(
        stmt: Statement<'a>,
        stmts: &mut StatementIter<'a>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        match stmt {
            Statement::EmptyStatement(_) => (),
            Statement::VariableDeclaration(var_decl) => {
                Self::handle_variable_declaration(var_decl, result, ctx);
            }
            Statement::ExpressionStatement(expr_stmt) => {
                Self::handle_expression_statement(expr_stmt, result, ctx);
            }
            Statement::SwitchStatement(switch_stmt) => {
                Self::handle_switch_statement(switch_stmt, result, ctx);
            }
            Statement::IfStatement(if_stmt) => {
                Self::handle_if_statement(stmts, if_stmt, result, ctx);
            }
            Statement::ReturnStatement(ret_stmt) => {
                Self::handle_return_statement(ret_stmt, result, ctx);
            }
            Statement::ThrowStatement(throw_stmt) => {
                Self::handle_throw_statement(throw_stmt, result, ctx);
            }
            Statement::ForStatement(for_stmt) => {
                Self::handle_for_statement(for_stmt, result, ctx);
            }
            Statement::ForInStatement(for_in_stmt) => {
                Self::handle_for_in_statement(for_in_stmt, result, ctx);
            }
            Statement::ForOfStatement(for_of_stmt) => {
                Self::handle_for_of_statement(for_of_stmt, result, ctx);
            }
            Statement::BlockStatement(block_stmt) => Self::handle_block(result, block_stmt, ctx),
            stmt => result.push(stmt),
        }
    }

    /// Merge `expr` expression with the previous expression statement or emit as a new one.
    fn push_new_expression_stmt_to_result(
        expr: Expression<'a>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        if ctx.options().sequences
            && let Some(Statement::ExpressionStatement(prev_expr_stmt)) = result.last_mut()
        {
            ctx.replace_expression_with(&mut prev_expr_stmt.expression, |a, ctx| {
                Self::join_sequence(a, expr, ctx)
            });
        } else {
            result.push(Statement::new_expression_statement(expr.span(), expr, ctx));
            ctx.notice_change();
        }
    }

    /// Fold `target` expression into previous expression as sequence
    /// `a; b` -> `a, b`.
    fn merge_last_expression_into_sequence(
        target: &mut Expression<'a>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        if !ctx.options().sequences
            || !matches!(result.last(), Some(Statement::ExpressionStatement(_)))
        {
            return;
        }
        let last_epr = result.pop().unwrap();
        let Statement::ExpressionStatement(prev_expr_stmt) = last_epr else { unreachable!() };
        let a = prev_expr_stmt.unbox().expression;
        ctx.replace_expression_with(target, |b, ctx| Self::join_sequence(a, b, ctx));
    }

    /// For variable declarations:
    /// * merge with the previous variable declarator if their kinds are the same
    /// * remove the variable declarator if it is unused
    /// * keep the initializer if it has side effects
    fn handle_variable_declaration(
        mut var_decl: ArenaBox<'a, VariableDeclaration<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        if let Some(first_decl) = var_decl.declarations.first_mut()
            && let Some(first_decl_init) = first_decl.init.as_mut()
        {
            Self::substitute_single_use_symbol_in_statement(first_decl_init, result, ctx, false);
            // "var a; var b = (a = 1, c);" => "var a = 1; var b = c;"
            Self::merge_leading_assignments_to_declaration(first_decl_init, false, result, ctx);
        }
        Self::substitute_single_use_symbol_within_declaration(
            var_decl.kind,
            &mut var_decl.declarations,
            ctx,
        );

        // If `join_vars` is off, but there are unused declarators ... just join them to make our code simpler.
        if !ctx.options().join_vars
            && var_decl
                .declarations
                .iter()
                .all(|d| !Self::should_remove_unused_declarator(d, var_decl.kind, ctx))
        {
            result.push(Statement::VariableDeclaration(var_decl));
            return;
        }

        if let Some(Statement::VariableDeclaration(prev_var_decl)) = result.last()
            && var_decl.kind == prev_var_decl.kind
        {
            ctx.notice_change();
        }
        let VariableDeclaration { span, kind, declarations, declare, .. } = var_decl.unbox();
        for mut decl in declarations {
            if Self::should_remove_unused_declarator(&decl, kind, ctx) {
                // `init` is `mut` because `remove_unused_expression` rewrites
                // it in place (peeling pure-call wrappers, etc). It is taken
                // out first because it may survive as an expression statement
                // — the declarator walk below must not mark its refs dead.
                if let Some(mut init) = decl.init.take() {
                    if Self::remove_unused_expression(&mut init, ctx) {
                        ctx.drop_expression(&init);
                    } else {
                        Self::push_new_expression_stmt_to_result(init, result, ctx);
                    }
                }
                // Walk the rest of the dropped declarator (binding pattern +
                // TS type annotation, which can contain references). Also
                // records the mutation for the fixed-point loop driver.
                ctx.drop_variable_declarator(&decl);
            } else {
                if let Some(Statement::VariableDeclaration(prev_var_decl)) = result.last_mut()
                    && kind == prev_var_decl.kind
                {
                    prev_var_decl.declarations.push(decl);
                    continue;
                }
                let new_decl =
                    Statement::new_variable_declaration(span, kind, [decl], declare, ctx);
                result.push(new_decl);
            }
        }
    }

    fn handle_expression_statement(
        mut expr_stmt: ArenaBox<'a, ExpressionStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        Self::substitute_single_use_symbol_in_statement(
            &mut expr_stmt.expression,
            result,
            ctx,
            false,
        );

        // In a derived constructor, `this` after an unconditional `super()` is safe to drop.
        // Walk backwards through preceding sibling statements looking for `super()`.
        // Only consider top-level expression statements — `super()` inside `if`/loops
        // is conditional and doesn't guarantee `this` is initialized.
        if matches!(expr_stmt.expression, Expression::ThisExpression(_))
            && Self::derived_constructor_this_scope(ctx).is_some()
            && result.iter().rev().any(|stmt| {
                matches!(
                    stmt,
                    Statement::ExpressionStatement(prev)
                        if Self::expression_contains_super_call(&prev.expression)
                )
            })
        {
            let dropped = Statement::ExpressionStatement(expr_stmt);
            ctx.drop_statement(&dropped);
            return;
        }

        // `a; b;` => `a, b;`
        Self::merge_last_expression_into_sequence(&mut expr_stmt.expression, result, ctx);

        // `var a; a = b();` => `var a = b();`
        if Self::merge_leading_assignments_to_declaration(
            &mut expr_stmt.expression,
            true,
            result,
            ctx,
        ) {
            let dropped = Statement::ExpressionStatement(expr_stmt);
            ctx.drop_statement(&dropped);
            return;
        }

        result.push(Statement::ExpressionStatement(expr_stmt));
    }

    /// Merge a single assignment into a matching uninitialized declarator of the
    /// variable declaration that immediately precedes it in `result`.
    fn merge_assignment_to_declaration(
        assign_expr: &mut AssignmentExpression<'a>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &TraverseCtx<'a>,
    ) -> bool {
        if assign_expr.operator != AssignmentOperator::Assign {
            return false;
        }
        let AssignmentTarget::AssignmentTargetIdentifier(id) = &assign_expr.left else {
            return false;
        };
        let Some(Statement::VariableDeclaration(var_decl)) = result.last_mut() else {
            return false;
        };
        if !matches!(&var_decl.kind, VariableDeclarationKind::Var | VariableDeclarationKind::Let) {
            return false;
        }
        let declaration_kind = var_decl.kind;
        for decl in var_decl.declarations.iter_mut().rev() {
            let BindingPattern::BindingIdentifier(kind) = &decl.id else {
                break;
            };
            if kind.name == id.name {
                if decl.init.is_none()
                    && (declaration_kind == VariableDeclarationKind::Var
                        || assign_expr.right.is_literal_value(true, ctx))
                {
                    // "var a; a = b();" => "var a = b();"
                    decl.init = Some(assign_expr.right.take_in(ctx));
                    return true;
                }
                // Note it is not possible to compress like:
                // - "var a = b(); a = c();" => "var a = (b(), c());"
                //   This is not possible as we need to consider cases when `c()` accesses `a`
                // - "var a = 1; a = b();" => "var a = b();"
                //   This is not possible as we need to consider cases when `b()` accesses `a`
                // - "let a; a = foo(a);" => "let a = foo(a);"
                //   This is not possible as TDZ error would be introduced
                break;
            }
            // should not move assignment above variables with initializer to keep the execution order
            if decl.init.is_some() {
                break;
            }
            // should not move assignment above other variables for let
            // this could cause TDZ errors (e.g. `let a, b; b = a;`)
            if declaration_kind == VariableDeclarationKind::Let {
                break;
            }
        }
        false
    }

    /// Fold leading assignments in `expr` into the variable declaration.
    fn merge_leading_assignments_to_declaration(
        expr: &mut Expression<'a>,
        value_is_discarded: bool,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) -> bool {
        let Some(Statement::VariableDeclaration(_)) = result.last() else {
            return false;
        };

        match expr {
            // "var a; a = b();" => "var a = b();"
            Expression::AssignmentExpression(assign_expr) if value_is_discarded => {
                Self::merge_assignment_to_declaration(assign_expr, result, ctx)
            }
            // "var a; return a = b(), c;" => "var a = b(); return c;"
            Expression::SequenceExpression(sequence_expr) => {
                // The value of the last expression is observed unless discarded.
                let limit = sequence_expr.expressions.len() - usize::from(!value_is_discarded);
                let first_non_merged_index =
                    sequence_expr.expressions.iter_mut().take(limit).position(|expr| match expr {
                        Expression::AssignmentExpression(assign_expr) => {
                            !Self::merge_assignment_to_declaration(assign_expr, result, ctx)
                        }
                        _ => true,
                    });
                // `None` means every candidate merged, so the whole prefix is taken.
                let taken = first_non_merged_index.unwrap_or(limit);
                if taken == 0 {
                    return false;
                }
                match sequence_expr.expressions.len() - taken {
                    // all elements are merged
                    0 => true,
                    // all elements are merged except for the last expression
                    1 => {
                        let only_expr = sequence_expr.expressions.pop().unwrap();
                        ctx.replace_expression(expr, only_expr);
                        false
                    }
                    // The sequence stays in the AST, so remove the targets here.
                    _ => {
                        for dropped in sequence_expr.expressions.drain(0..taken) {
                            ctx.drop_expression(&dropped);
                        }
                        false
                    }
                }
            }
            _ => false,
        }
    }

    /// Check if a switch case can be inlined by verifying:
    /// - The test expression has no side effects
    /// - All statements can be safely inlined (no unlabeled breaks)
    pub fn can_switch_case_be_inlined(case: &SwitchCase<'a>) -> bool {
        if !case.test.as_ref().is_none_or(Expression::is_literal) {
            return false;
        }

        case.consequent.is_empty() || !FindNestedBreak::has_unlabelled_break_in_switch_case(case)
    }

    fn handle_switch_statement(
        mut switch_stmt: ArenaBox<'a, SwitchStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        Self::substitute_single_use_symbol_in_statement(
            &mut switch_stmt.discriminant,
            result,
            ctx,
            false,
        );

        // `a; switch(b){}` => `switch(a, b){}`
        Self::merge_last_expression_into_sequence(&mut switch_stmt.discriminant, result, ctx);

        // `var a; switch (a = b(), c) {}` => `var a = b(); switch (c) {}`
        Self::merge_leading_assignments_to_declaration(
            &mut switch_stmt.discriminant,
            false,
            result,
            ctx,
        );

        if !ctx.is_tree_shake_only()
            && switch_stmt.cases.len() == 1
            && Self::can_switch_case_be_inlined(&switch_stmt.cases[0])
            && let Some(case) = switch_stmt.cases.pop()
        {
            ctx.notice_change();
            let switch_scope_id = switch_stmt.scope_id();
            let SwitchStatement { span: switch_span, discriminant, .. } = switch_stmt.unbox();
            let SwitchCase { span: case_span, test, mut consequent, .. } = case;

            let block_stmt =
                if consequent.len() == 1 && matches!(consequent[0], Statement::BlockStatement(_)) {
                    consequent.pop().unwrap()
                } else {
                    Statement::new_block_statement_with_scope_id(
                        case_span,
                        consequent,
                        switch_scope_id,
                        ctx,
                    )
                };

            if let Some(test) = test {
                result.push(Statement::new_if_statement(
                    switch_span,
                    Expression::new_binary_expression(
                        SPAN,
                        discriminant,
                        BinaryOperator::StrictEquality,
                        test,
                        ctx,
                    ),
                    block_stmt,
                    None,
                    ctx,
                ));
                return;
            }

            if !discriminant.is_literal() {
                Self::push_new_expression_stmt_to_result(discriminant, result, ctx);
            }

            result.push(block_stmt);
            return;
        }

        result.push(Statement::SwitchStatement(switch_stmt));
    }

    fn handle_if_statement(
        stmts: &mut StatementIter<'a>,
        mut if_stmt: ArenaBox<'a, IfStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        Self::substitute_single_use_symbol_in_statement(&mut if_stmt.test, result, ctx, false);

        // `var a; if (a = b(), c) d;` => `var a = b(); if (c) d;`
        Self::merge_leading_assignments_to_declaration(&mut if_stmt.test, false, result, ctx);

        // `a; if (b) c;` => `if (a, b) c;`
        Self::merge_last_expression_into_sequence(&mut if_stmt.test, result, ctx);

        if ctx.options().sequences {
            if let Some(Statement::IfStatement(prev_if_stmt)) = result.last_mut()
                && prev_if_stmt.alternate.is_none()
                && if_stmt.consequent.is_terminated()
                && prev_if_stmt.consequent.content_eq(&if_stmt.consequent)
            {
                // Merge previous stmt if its terminated and both have same content
                // `if (a) JUMP; if (b) JUMP;` => `if (a || b) JUMP;`
                // `if (a) { b; JUMP }; if (b) { b; JUMP };` => `if (a || b) { b; JUMP };`
                let previous = result.pop().unwrap();
                let Statement::IfStatement(previous) = previous else { unreachable!() };
                let previous = previous.unbox();
                let span = if_stmt.test.span();
                ctx.replace_expression_with(&mut if_stmt.test, |test, ctx| {
                    Self::join_with_left_associative_op(
                        span,
                        LogicalOperator::Or,
                        previous.test,
                        test,
                        ctx,
                    )
                });
                ctx.drop_statement(&previous.consequent);
            }

            let can_merge_with_alternate = match &if_stmt.consequent {
                Statement::BlockStatement(block) => block.body.last().is_some_and(|last_stmt| {
                    Self::can_remove_termination_statement(last_stmt, ctx)
                }),
                stmt => Self::can_remove_termination_statement(stmt, ctx),
            };
            if can_merge_with_alternate {
                // Don't do this transformation if the branch condition could
                // potentially access symbols declared later on on this scope below.
                // If so, inverting the branch condition and nesting statements after
                // this in a block would break that access which is a behavior change.
                //
                //   // This transformation is incorrect
                //   if (a()) return; function a() {}
                //   if (!a()) { function a() {} }
                //
                //   // This transformation is incorrect
                //   if (a(() => b)) return; let b;
                //   if (a(() => b)) { let b; }
                //
                let can_move_branch_condition_outside_scope =
                    !if_stmt.alternate.as_ref().is_some_and(Self::statement_cares_about_scope)
                        && !stmts.as_slice().iter().any(Self::statement_cares_about_scope);

                if can_move_branch_condition_outside_scope {
                    let drained_stmts = stmts.by_ref();
                    let mut body = if let Some(alternate) = if_stmt.alternate.take() {
                        ArenaVec::from_iter_in(iter::once(alternate).chain(drained_stmts), ctx)
                    } else {
                        ArenaVec::from_iter_in(drained_stmts, ctx)
                    };
                    let span = if body.is_empty() { SPAN } else { body[0].span() };
                    Self::minimize_statements(&mut body, ctx);
                    let alternate = if body.len() == 1 {
                        body.remove(0)
                    } else {
                        let scope_id = ctx.create_child_scope_of_current(ScopeFlags::empty());
                        Statement::new_block_statement_with_scope_id(span, body, scope_id, ctx)
                    };

                    if let Statement::BlockStatement(block) = &mut if_stmt.consequent {
                        ctx.drop_statement(&block.body.pop().unwrap());
                        // after removal check if there is one remaining stmt and if it requires block
                        // IfStatement is excluded as we would add it afterward in `try_minimize_if`
                        if block.body.len() == 1
                            && !matches!(&block.body[0], Statement::IfStatement(_))
                            && !Self::statement_cares_about_scope(&block.body[0])
                        {
                            let new_stmt = block.body.remove(0);
                            ctx.replace_statement(&mut if_stmt.consequent, new_stmt);
                        }
                        if_stmt.alternate = Some(alternate);
                    } else {
                        ctx.replace_expression_with(&mut if_stmt.test, |test, ctx| {
                            Self::minimize_not(test.span(), test, ctx, true)
                        });
                        ctx.replace_statement(&mut if_stmt.consequent, alternate);
                    }

                    let mut if_stmt = Statement::IfStatement(if_stmt);
                    Self::try_minimize_if(&mut if_stmt, ctx);
                    ctx.notice_change();
                    Self::minimize_statement(if_stmt, stmts, result, ctx);
                    return;
                }
            }

            if !if_stmt.alternate.as_ref().is_none_or(Self::statement_cares_about_scope)
                && if_stmt.consequent.is_terminated()
                && let Some(stmt) = if_stmt.alternate.take()
            {
                // "if (a) return b; else if (c) return d; else return e;" => "if (a) return b; if (c) return d; return e;"
                ctx.notice_change();
                result.push(Statement::IfStatement(if_stmt));
                Self::minimize_statement(stmt, stmts, result, ctx);
                return;
            }
        }

        result.push(Statement::IfStatement(if_stmt));
    }

    fn handle_return_statement(
        mut ret_stmt: ArenaBox<'a, ReturnStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        if let Some(ret_argument_expr) = &mut ret_stmt.argument {
            Self::substitute_single_use_symbol_in_statement(ret_argument_expr, result, ctx, false);
            // `var a; return a = b(), c;` => `var a = b(); return c;`
            Self::merge_leading_assignments_to_declaration(ret_argument_expr, false, result, ctx);
        }

        if let Some(argument) = &ret_stmt.argument
            && argument.value_type(ctx) == ValueType::Undefined
            // `return undefined` has a different semantic in async generator function.
            && !ctx.is_closest_function_scope_an_async_generator()
        {
            let argument = ret_stmt.argument.take().unwrap();
            if argument.may_have_side_effects(ctx) {
                // `x; return a,void 0;` -> `x,a,void 0; return;`
                // `return a,void 0;` -> `a,void 0; return;`
                Self::push_new_expression_stmt_to_result(argument, result, ctx);
            } else {
                // `return void 0;` -> `return;`
                ctx.drop_expression(&argument);
            }
        } else if let Some(argument) = &mut ret_stmt.argument {
            // `a; return b;` => `return b, c;`
            Self::merge_last_expression_into_sequence(argument, result, ctx);
        }

        // `if (a) return b; return c;` => `return a ? b : c;`
        // `if (a) return; return;` => `a; return;`
        if ctx.options().sequences {
            'return_loop: while !result.is_empty() {
                if let Some(Statement::IfStatement(if_stmt)) = result.last()
                    && if_stmt.alternate.is_none()
                    && let Statement::ReturnStatement(prev_return) = &if_stmt.consequent
                {
                    let prev_has_arg = prev_return.argument.is_some();
                    let ret_has_arg = ret_stmt.argument.is_some();

                    if !prev_has_arg && !ret_has_arg {
                        // `if (a) return; return;` => `a; return;`
                        ctx.notice_change();
                        let prev_stmt = result.pop().unwrap();
                        let Statement::IfStatement(prev_if) = prev_stmt else { unreachable!() };
                        let test_expr = prev_if.unbox().test;

                        Self::push_new_expression_stmt_to_result(test_expr, result, ctx);
                        break 'return_loop;
                    }

                    // do not collapse if conditional count exceeded
                    if ret_stmt
                        .argument
                        .as_ref()
                        .is_some_and(Self::conditional_expression_count_exceeded)
                    {
                        break 'return_loop;
                    }
                    // do not collapse if return could be removed
                    if !ret_has_arg && ctx.parent().is_function_body() {
                        break 'return_loop;
                    }
                    // do not collapse if parent is async generator and any of arguments is empty
                    if (!prev_has_arg || !ret_has_arg)
                        && ctx.is_closest_function_scope_an_async_generator()
                    {
                        break 'return_loop;
                    }

                    // `if (a) return b; return c;` => `return a ? b : c;`
                    ctx.notice_change();
                    let prev_stmt = result.pop().unwrap();
                    let Statement::IfStatement(prev_if) = prev_stmt else { unreachable!() };
                    let prev_if = prev_if.unbox();
                    let Statement::ReturnStatement(mut prev_return) = prev_if.consequent else {
                        unreachable!()
                    };

                    let left_span = prev_return.span();
                    let right_span = ret_stmt.span();
                    // "if (a) return; return b;" => "return a ? void 0 : b;"
                    let left = prev_return
                        .argument
                        .take()
                        .unwrap_or_else(|| Expression::new_void_0(left_span, ctx));
                    // "if (a) return a; return;" => "return a ? b : void 0;"
                    let right = ret_stmt
                        .argument
                        .take()
                        .unwrap_or_else(|| Expression::new_void_0(right_span, ctx));

                    let argument =
                        Self::minimize_conditional(prev_if.span, prev_if.test, left, right, ctx);
                    ret_stmt.argument = Some(argument);
                } else {
                    break 'return_loop;
                }
            }
        }

        result.push(Statement::ReturnStatement(ret_stmt));
    }

    fn handle_throw_statement(
        mut throw_stmt: ArenaBox<'a, ThrowStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        Self::substitute_single_use_symbol_in_statement(
            &mut throw_stmt.argument,
            result,
            ctx,
            false,
        );

        // `a; throw b;` => `throw a, b;`
        Self::merge_last_expression_into_sequence(&mut throw_stmt.argument, result, ctx);

        // `var a; throw a = b(), c;` => `var a = b(); throw c;`
        Self::merge_leading_assignments_to_declaration(
            &mut throw_stmt.argument,
            false,
            result,
            ctx,
        );

        // `if (a) throw b; throw c;` => `throw a ? b : c;`
        if ctx.options().sequences {
            'Loop: while !result.is_empty() {
                if let Some(Statement::IfStatement(if_stmt)) = result.last()
                    && if_stmt.alternate.is_none()
                    && matches!(&if_stmt.consequent, Statement::ThrowStatement(_))
                    && !Self::conditional_expression_count_exceeded(&throw_stmt.argument)
                {
                    ctx.notice_change();
                    let prev_stmt = result.pop().unwrap();
                    let Statement::IfStatement(prev_if) = prev_stmt else { unreachable!() };
                    let prev_if = prev_if.unbox();
                    let Statement::ThrowStatement(prev_throw) = prev_if.consequent else {
                        unreachable!()
                    };

                    ctx.replace_expression_with(&mut throw_stmt.argument, |expr, ctx| {
                        Self::minimize_conditional(
                            prev_if.span,
                            prev_if.test,
                            prev_throw.unbox().argument,
                            expr,
                            ctx,
                        )
                    });
                } else {
                    break 'Loop;
                }
            }
        }

        result.push(Statement::ThrowStatement(throw_stmt));
    }

    fn handle_for_statement(
        mut for_stmt: ArenaBox<'a, ForStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        if let Some(init) = &mut for_stmt.init {
            match init {
                ForStatementInit::VariableDeclaration(var_decl) => {
                    let declaration_kind = var_decl.kind;
                    if let Some(first_decl) = var_decl.declarations.first_mut()
                        && let Some(first_decl_init) = first_decl.init.as_mut()
                    {
                        let is_block_scoped_decl = !declaration_kind.is_var();
                        Self::substitute_single_use_symbol_in_statement(
                            first_decl_init,
                            result,
                            ctx,
                            is_block_scoped_decl,
                        );
                    }
                    Self::substitute_single_use_symbol_within_declaration(
                        var_decl.kind,
                        &mut var_decl.declarations,
                        ctx,
                    );
                }
                match_expression!(ForStatementInit) => {
                    let init = init.to_expression_mut();
                    Self::substitute_single_use_symbol_in_statement(init, result, ctx, false);
                    // "var a; for (a = b(), c; ;) d;" => "var a = b(); for (c; ;) d;"
                    if Self::merge_leading_assignments_to_declaration(init, true, result, ctx)
                        && let Some(old_init) = for_stmt.init.take()
                    {
                        ctx.drop_expression(old_init.to_expression());
                    }
                }
            }
        }

        if let Some(ForStatementInit::VariableDeclaration(var_decl)) = &mut for_stmt.init {
            let declaration_kind = var_decl.kind;
            let old_len = var_decl.declarations.len();
            var_decl.declarations.retain_mut(|decl| {
                let should_keep =
                    !Self::should_remove_unused_declarator(decl, declaration_kind, ctx)
                        || decl.init.as_ref().is_some_and(|init| {
                            Self::has_side_effects_or_preserved_iife(init, ctx)
                        });
                if !should_keep {
                    // Same leak hazard as `remove_unused_variable_declaration`:
                    // the `retain` silently drops the declarator, so its refs
                    // (init and TS type annotation) need an explicit walk to
                    // reach `PassChanges`.
                    ctx.drop_variable_declarator(decl);
                }
                should_keep
            });
            if old_len != var_decl.declarations.len() {
                if var_decl.declarations.is_empty() {
                    for_stmt.init = None;
                }
                ctx.notice_change();
            }
        }

        if ctx.options().sequences {
            match result.last_mut() {
                Some(Statement::ExpressionStatement(_)) => {
                    if let Some(init) = &mut for_stmt.init {
                        if let Some(init) = init.as_expression_mut() {
                            // `a; for (b;;) c;` => `for (a, b;;) c;`
                            Self::merge_last_expression_into_sequence(init, result, ctx);
                        }
                    } else {
                        let previous = result.pop().unwrap();
                        let Statement::ExpressionStatement(previous) = previous else {
                            unreachable!()
                        };
                        for_stmt.init = Some(ForStatementInit::from(previous.unbox().expression));
                        ctx.notice_change();
                    }
                }
                Some(Statement::VariableDeclaration(prev_var_decl)) => {
                    if let Some(init) = &mut for_stmt.init {
                        if prev_var_decl.kind.is_var()
                            && let ForStatementInit::VariableDeclaration(var_decl) = init
                            && var_decl.kind.is_var()
                        {
                            var_decl
                                .declarations
                                .splice(0..0, prev_var_decl.declarations.drain(..));
                            let dropped = result.pop().unwrap();
                            ctx.drop_statement(&dropped);
                        }
                    } else if prev_var_decl.kind.is_var() {
                        let Some(Statement::VariableDeclaration(prev_var_decl)) = result.pop()
                        else {
                            unreachable!()
                        };
                        for_stmt.init = Some(ForStatementInit::VariableDeclaration(prev_var_decl));
                        ctx.notice_change();
                    }
                }
                _ => {}
            }
        }
        result.push(Statement::ForStatement(for_stmt));
    }

    fn handle_for_in_statement(
        mut for_in_stmt: ArenaBox<'a, ForInStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,

        ctx: &mut TraverseCtx<'a>,
    ) {
        // Annex B.3.5 allows initializers in non-strict mode
        // <https://tc39.es/ecma262/multipage/additional-ecmascript-features-for-web-browsers.html#sec-initializers-in-forin-statement-heads>
        // That is evaluated before the right hand side is evaluated. So, in that case, skip the single use substitution.
        if !matches!(&for_in_stmt.left, ForStatementLeft::VariableDeclaration(var_decl) if var_decl.has_init())
        {
            let is_block_scoped_decl = matches!(&for_in_stmt.left, ForStatementLeft::VariableDeclaration(var_decl) if !var_decl.kind.is_var());
            Self::substitute_single_use_symbol_in_statement(
                &mut for_in_stmt.right,
                result,
                ctx,
                is_block_scoped_decl,
            );
            // "var a; for (b in a = c(), d) e;" => "var a = c(); for (b in d) e;"
            if !for_in_stmt.left.is_lexical_declaration() {
                Self::merge_leading_assignments_to_declaration(
                    &mut for_in_stmt.right,
                    false,
                    result,
                    ctx,
                );
            }
        }

        if ctx.options().sequences {
            match result.last_mut() {
                // "a; for (var b in c) d" => "for (var b in a, c) d"
                Some(Statement::ExpressionStatement(_)) => {
                    // Annex B.3.5 allows initializers in non-strict mode
                    // <https://tc39.es/ecma262/multipage/additional-ecmascript-features-for-web-browsers.html#sec-initializers-in-forin-statement-heads>
                    // Only allow inlining when the for-in variable is declared with `var` and
                    // there's not a side-effectful initializer.
                    // Block-scoped declarations (let/const) can cause variable shadowing issues
                    // where the inlined expression might reference a variable with the same name
                    // as the for-in variable, but after inlining, it would incorrectly refer to
                    // the shadowed for-in variable instead.
                    // <https://github.com/oxc-project/oxc/issues/18650>
                    let can_inline = if let ForStatementLeft::VariableDeclaration(var_decl) =
                        &for_in_stmt.left
                    {
                        match var_decl.declarations.as_slice() {
                            [decl] => {
                                var_decl.kind.is_var()
                                    && !decl
                                        .init
                                        .as_ref()
                                        .is_some_and(|init| init.may_have_side_effects(ctx))
                            }
                            _ => false,
                        }
                    } else {
                        true
                    };
                    if can_inline {
                        Self::merge_last_expression_into_sequence(
                            &mut for_in_stmt.right,
                            result,
                            ctx,
                        );
                    }
                }
                // "var a; for (a in b) c" => "for (var a in b) c"
                Some(Statement::VariableDeclaration(prev_var_decl)) => {
                    if let ForStatementLeft::AssignmentTargetIdentifier(id) = &for_in_stmt.left {
                        let prev_var_decl_no_init_item = {
                            if prev_var_decl.kind.is_var()
                                && prev_var_decl.declarations.len() == 1
                                && prev_var_decl.declarations[0].init.is_none()
                            {
                                Some(&prev_var_decl.declarations[0])
                            } else {
                                None
                            }
                        };
                        if let Some(prev_var_decl_item) = prev_var_decl_no_init_item
                            && let BindingPattern::BindingIdentifier(decl_id) =
                                &prev_var_decl_item.id
                            && id.name == decl_id.name
                        {
                            let Some(Statement::VariableDeclaration(prev_var_decl)) = result.pop()
                            else {
                                unreachable!()
                            };
                            let new_left = ForStatementLeft::VariableDeclaration(prev_var_decl);
                            ctx.replace_for_statement_left(&mut for_in_stmt.left, new_left);
                        }
                    }
                }
                _ => {}
            }
        }
        result.push(Statement::ForInStatement(for_in_stmt));
    }

    fn handle_for_of_statement(
        mut for_of_stmt: ArenaBox<'a, ForOfStatement<'a>>,
        result: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        let is_block_scoped_decl = matches!(&for_of_stmt.left, ForStatementLeft::VariableDeclaration(var_decl) if !var_decl.kind.is_var());
        Self::substitute_single_use_symbol_in_statement(
            &mut for_of_stmt.right,
            result,
            ctx,
            is_block_scoped_decl,
        );

        if !for_of_stmt.left.is_lexical_declaration() {
            // "var a; for (b of a = c(), d) e;" => "var a = c(); for (b of d) e;"
            Self::merge_leading_assignments_to_declaration(
                &mut for_of_stmt.right,
                false,
                result,
                ctx,
            );
        }

        // "var a; for (a of b) c" => "for (var a of b) c"
        if let Some(Statement::VariableDeclaration(prev_var_decl)) = result.last_mut()
            && let ForStatementLeft::AssignmentTargetIdentifier(id) = &for_of_stmt.left
        {
            let prev_var_decl_no_init_item = {
                if prev_var_decl.kind.is_var()
                    && prev_var_decl.declarations.len() == 1
                    && prev_var_decl.declarations[0].init.is_none()
                {
                    Some(&prev_var_decl.declarations[0])
                } else {
                    None
                }
            };
            if let Some(prev_var_decl_item) = prev_var_decl_no_init_item
                && let BindingPattern::BindingIdentifier(decl_id) = &prev_var_decl_item.id
                && id.name == decl_id.name
            {
                let Some(Statement::VariableDeclaration(prev_var_decl)) = result.pop() else {
                    unreachable!()
                };
                let new_left = ForStatementLeft::VariableDeclaration(prev_var_decl);
                ctx.replace_for_statement_left(&mut for_of_stmt.left, new_left);
            }
        }
        result.push(Statement::ForOfStatement(for_of_stmt));
    }

    /// `appendIfOrLabelBodyPreservingScope`: <https://github.com/evanw/esbuild/blob/v0.24.2/internal/js_parser/js_parser.go#L9839>
    fn handle_block(
        result: &mut ArenaVec<'a, Statement<'a>>,
        block_stmt: ArenaBox<'a, BlockStatement<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) {
        let keep_block = block_stmt.body.iter().any(Self::statement_cares_about_scope);
        if keep_block {
            result.push(Statement::BlockStatement(block_stmt));
        } else {
            result.append(&mut block_stmt.unbox().body);
            ctx.notice_change();
        }
    }

    /// `statementCaresAboutScope`: <https://github.com/evanw/esbuild/blob/v0.24.2/internal/js_parser/js_parser.go#L9754-L9768>
    pub fn statement_cares_about_scope(stmt: &Statement<'a>) -> bool {
        match stmt {
            Statement::BlockStatement(_)
            | Statement::EmptyStatement(_)
            | Statement::DebuggerStatement(_)
            | Statement::ExpressionStatement(_)
            | Statement::IfStatement(_)
            | Statement::ForStatement(_)
            | Statement::ForInStatement(_)
            | Statement::ForOfStatement(_)
            | Statement::DoWhileStatement(_)
            | Statement::WhileStatement(_)
            | Statement::WithStatement(_)
            | Statement::TryStatement(_)
            | Statement::SwitchStatement(_)
            | Statement::ReturnStatement(_)
            | Statement::ThrowStatement(_)
            | Statement::BreakStatement(_)
            | Statement::ContinueStatement(_) => false,
            Statement::LabeledStatement(label) => Self::statement_cares_about_scope(&label.body),
            Statement::VariableDeclaration(decl) => !decl.kind.is_var(),
            _ => true,
        }
    }

    /// Inline single-use variable declarations where possible:
    /// ```js
    /// // before
    /// let x = fn();
    /// return x.y();
    ///
    /// // after
    /// return fn().y();
    /// ```
    ///
    /// part of `mangleStmts`: <https://github.com/evanw/esbuild/blob/v0.25.9/internal/js_parser/js_parser.go#L9111-L9189>
    /// `substituteSingleUseSymbolInStmt`: <https://github.com/evanw/esbuild/blob/v0.25.9/internal/js_parser/js_parser.go#L9583>
    fn substitute_single_use_symbol_in_statement(
        expr_in_stmt: &mut Expression<'a>,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a>,
        non_scoped_literal_only: bool,
    ) -> bool {
        if Self::is_script_root_scope(ctx) || ctx.current_scope_flags().contains_direct_eval() {
            return false;
        }

        let mut inlined = false;
        while let Some(Statement::VariableDeclaration(prev_var_decl)) = stmts.last_mut() {
            if prev_var_decl.kind.is_using() {
                break;
            }
            let old_len = prev_var_decl.declarations.len();
            let new_len = Self::substitute_single_use_symbol_in_expression_from_declarators(
                expr_in_stmt,
                &mut prev_var_decl.declarations,
                ctx,
                non_scoped_literal_only,
            );
            // The inlined declarators' inits were already taken out by the
            // substitution, but the discarded declarators themselves still
            // need a drop walk — their TS type annotations can hold resolved
            // references (computed keys in a type literal).
            if new_len == 0 {
                inlined = true;
                let dropped = stmts.pop().unwrap();
                ctx.drop_statement(&dropped);
            } else if old_len != new_len {
                inlined = true;
                for decl in prev_var_decl.declarations.drain(new_len..) {
                    ctx.drop_variable_declarator(&decl);
                }
                break;
            } else {
                break;
            }
        }
        inlined
    }

    fn substitute_single_use_symbol_within_declaration(
        kind: VariableDeclarationKind,
        declarations: &mut ArenaVec<'a, VariableDeclarator<'a>>,
        ctx: &mut TraverseCtx<'a>,
    ) -> bool {
        if Self::is_script_root_scope(ctx)
            || ctx.current_scope_flags().contains_direct_eval()
            || kind.is_using()
        {
            return false;
        }

        let mut changed = false;
        let mut i = 1;
        while i < declarations.len() {
            let (prev_decls, [decl, ..]) = declarations.split_at_mut(i) else { unreachable!() };
            let Some(decl_init) = &mut decl.init else {
                i += 1;
                continue;
            };
            let old_len = prev_decls.len();
            let new_len = Self::substitute_single_use_symbol_in_expression_from_declarators(
                decl_init, prev_decls, ctx, false,
            );
            if old_len != new_len {
                changed = true;
                let drop_count = old_len - new_len;
                // Same drop-walk requirement as the truncate above: the
                // drained declarators' type annotations can hold references.
                for decl in declarations.drain(i - drop_count..i) {
                    ctx.drop_variable_declarator(&decl);
                }
                i -= drop_count;
            }
            i += 1;
        }
        changed
    }

    /// Returns new length.
    ///
    /// CONTRACT: the consumed suffix `declarators[new_len..]` is the caller's
    /// to discard, and the caller must route each discarded declarator through
    /// `ctx.drop_variable_declarator` (or an enclosing `drop_statement`) — the
    /// inlined inits are already taken out, but binding patterns and TS type
    /// annotations can still hold resolved references that would otherwise
    /// leak past the incremental scoping refresh.
    fn substitute_single_use_symbol_in_expression_from_declarators(
        target_expr: &mut Expression<'a>,
        declarators: &mut [VariableDeclarator<'a>],
        ctx: &mut TraverseCtx<'a>,
        non_scoped_literal_only: bool,
    ) -> usize {
        let last_non_inlined_index = declarators.iter_mut().rposition(|prev_decl| {
            let Some(prev_decl_init) = &mut prev_decl.init else {
                return true;
            };
            let BindingPattern::BindingIdentifier(prev_decl_id) = &prev_decl.id else {
                return true;
            };
            // Don't inline `var e` inside `catch (e) { ... }`. Removing the var declarator
            // would lose the function-scoped hoisting that `var` provides. The catch parameter
            // and the var share one symbol (with CatchVariable flag) due to the redeclaration
            // semantics in https://tc39.es/ecma262/#sec-variablestatements-in-catch-blocks
            if ctx.scoping().symbol_flags(prev_decl_id.symbol_id()).is_catch_variable() {
                return true;
            }
            if ctx.is_expression_whose_name_needs_to_be_kept(prev_decl_init) {
                return true;
            }
            let Some(symbol_value) = ctx.state.symbols.value(prev_decl_id.symbol_id()) else {
                return true;
            };
            // Implicitly observable bindings remain live independently of
            // their resolved-reference count.
            // An `export { foo }` specifier also contributes a reference, but
            // consult the shared metadata explicitly for consistency with the
            // other count-based consumers.
            if ctx.state.symbols.is_implicitly_observable(prev_decl_id.symbol_id())
                || symbol_value.references.has_multiple_reads()
                || symbol_value.references.has_writes()
            {
                return true;
            }
            if non_scoped_literal_only && !prev_decl_init.is_literal_value(false, ctx) {
                return true;
            }
            let replaced = Self::substitute_single_use_symbol_in_expression(
                target_expr,
                prev_decl_id.name,
                prev_decl_init,
                prev_decl_init.may_have_side_effects(ctx),
                ctx,
            );
            if replaced != Some(true) {
                return true;
            }
            false
        });
        match last_non_inlined_index {
            None => 0,
            Some(last_non_inlined_index) => last_non_inlined_index + 1,
        }
    }

    /// Returns Some(true) when the expression is successfully replaced.
    /// Returns Some(false) when the expression is not replaced, and cannot try the subsequent expressions.
    /// Return None when the expression is not replaced, and can try the subsequent expressions.
    ///
    /// `substituteSingleUseSymbolInExpr`: <https://github.com/evanw/esbuild/blob/v0.25.9/internal/js_parser/js_parser.go#L9642>
    fn substitute_single_use_symbol_in_expression(
        target_expr: &mut Expression<'a>,
        search_for: Ident<'a>,
        replacement: &mut Expression<'a>,
        replacement_has_side_effect: bool,
        ctx: &mut TraverseCtx<'a>,
    ) -> Option<bool> {
        match target_expr {
            Expression::Identifier(id) => {
                if id.name == search_for {
                    // Preserve the span of the target identifier so that comments
                    // attached to it (via `attached_to`) remain correctly associated
                    // with the replacement expression.
                    // https://github.com/rolldown/rolldown/issues/8248
                    let target_span = target_expr.span();
                    let mut new_expr = replacement.take_in(ctx);
                    // Span fix-up on the still-owned new node before the slot replacement, not the slot replacement itself.
                    *new_expr.span_mut() = target_span;
                    ctx.replace_expression(target_expr, new_expr);
                    return Some(true);
                }
                // If the identifier is not a getter and the identifier is read-only,
                // we know that the value is same even if we reordered the expression.
                // Imported names are live bindings, so local read-only status is
                // insufficient for them.
                //
                // But a lexical binding that is closed over from an enclosing
                // function/module scope may still be in its Temporal Dead Zone
                // when this function runs (e.g. the function is called before the
                // binding's declaration executes). Reordering its read earlier —
                // in particular before a side-effecting replacement such as an
                // `await` — can surface a `ReferenceError` that the original order
                // avoids. https://github.com/rolldown/rolldown/issues/9959
                if !Self::identifier_read_blocks_reorder(id, ctx) {
                    return None;
                }
            }
            Expression::AwaitExpression(await_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut await_expr.argument,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::YieldExpression(yield_expr) => {
                if let Some(argument) = &mut yield_expr.argument
                    && let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        argument,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    )
                {
                    return Some(changed);
                }
            }
            Expression::ImportExpression(import_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut import_expr.source,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }

                // The "import()" expression has side effects but the side effects are
                // always asynchronous so there is no way for the side effects to modify
                // the replacement value. So it's ok to reorder the replacement value
                // past the "import()" expression assuming everything else checks out.
                if !replacement_has_side_effect && !import_expr.source.may_have_side_effects(ctx) {
                    return None;
                }
            }
            Expression::UnaryExpression(unary_expr) => {
                if unary_expr.operator != UnaryOperator::Delete
                    && let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        &mut unary_expr.argument,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    )
                {
                    return Some(changed);
                }
            }
            Expression::StaticMemberExpression(member_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut member_expr.object,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::BinaryExpression(binary_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut binary_expr.left,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut binary_expr.right,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::AssignmentExpression(assign_expr) => {
                if assign_expr.left.may_have_side_effects(ctx) {
                    // Do not reorder past a side effect in an assignment target, as that may
                    // change the replacement value. For example, "fn()" may change "a" here:
                    // ```js
                    // let a = 1;
                    // foo[fn()] = a;
                    // ```
                    return Some(false);
                }
                if assign_expr.operator != AssignmentOperator::Assign && replacement_has_side_effect
                {
                    // If this is a read-modify-write assignment and the replacement has side
                    // effects, don't reorder it past the assignment target. The assignment
                    // target is being read so it may be changed by the side effect. For
                    // example, "fn()" may change "foo" here:
                    // ```js
                    // let a = fn();
                    // foo += a;
                    // ```
                    return Some(false);
                }
                if replacement_has_side_effect {
                    // If the assignment target may depend on side effects of the replacement,
                    // don't reorder it past the assignment target. The non-last part of the
                    // assignment target is evaluated before the assignment evaluation so that
                    // part may be changed by the side effect. For example, "fn()" may change
                    // "foo" here:
                    // ```js
                    // let a = fn();
                    // foo.bar = a;
                    // ```
                    let may_depend_on_side_effect = match &assign_expr.left {
                        AssignmentTarget::AssignmentTargetIdentifier(_) => false,
                        AssignmentTarget::ComputedMemberExpression(member_expr) => {
                            Self::member_part_blocks_reorder(&member_expr.object, ctx)
                                || Self::computed_key_blocks_reorder(
                                    &member_expr.expression,
                                    ctx,
                                )
                        }
                        AssignmentTarget::PrivateFieldExpression(member_expr) => {
                            Self::member_part_blocks_reorder(&member_expr.object, ctx)
                        }
                        AssignmentTarget::StaticMemberExpression(member_expr) => {
                            Self::member_part_blocks_reorder(&member_expr.object, ctx)
                        }
                        AssignmentTarget::ArrayAssignmentTarget(_)
                        | AssignmentTarget::ObjectAssignmentTarget(_)
                        | AssignmentTarget::TSAsExpression(_)
                        | AssignmentTarget::TSNonNullExpression(_)
                        | AssignmentTarget::TSSatisfiesExpression(_)
                        | AssignmentTarget::TSTypeAssertion(_) => true,
                    };
                    if may_depend_on_side_effect {
                        return Some(false);
                    }
                }
                // If we get here then it should be safe to attempt to substitute the
                // replacement past the left operand into the right operand.
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut assign_expr.right,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::LogicalExpression(logical_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut logical_expr.left,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
                // Do not substitute our unconditionally-executed value into a branch
                // unless the value itself has no side effects
                if !replacement_has_side_effect
                    && let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        &mut logical_expr.right,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    )
                {
                    return Some(changed);
                }
            }
            Expression::PrivateInExpression(private_in_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut private_in_expr.right,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::ConditionalExpression(cond_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut cond_expr.test,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
                // Do not substitute our unconditionally-executed value into a branch
                // unless the value itself has no side effects
                if !replacement_has_side_effect {
                    // Unlike other branches in this function such as "a && b" or "a?.[b]",
                    // the "a ? b : c" form has potential code evaluation along both control
                    // flow paths. Handle this by allowing substitution into either branch.
                    // Side effects in one branch should not prevent the substitution into
                    // the other branch.

                    let consequent_changed = Self::substitute_single_use_symbol_in_expression(
                        &mut cond_expr.consequent,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    );
                    if consequent_changed == Some(true) {
                        return consequent_changed;
                    }
                    let alternate_changed = Self::substitute_single_use_symbol_in_expression(
                        &mut cond_expr.alternate,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    );
                    if alternate_changed == Some(true) {
                        return alternate_changed;
                    }
                    // Side effects in either branch should stop us from continuing to try to
                    // substitute the replacement after the control flow branches merge again.
                    if consequent_changed == Some(false) || alternate_changed == Some(false) {
                        return Some(false);
                    }
                }
            }
            Expression::ComputedMemberExpression(member_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut member_expr.object,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
                // Do not substitute our unconditionally-executed value into a branch
                // unless the value itself has no side effects
                if (!replacement_has_side_effect || !member_expr.optional)
                    && let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        &mut member_expr.expression,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    )
                {
                    return Some(changed);
                }
            }
            Expression::PrivateFieldExpression(private_field_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut private_field_expr.object,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
            }
            Expression::CallExpression(call_expr)
                // Don't substitute something into a call target that could change "this"
                if !((replacement.is_member_expression()
                    || matches!(replacement, Expression::ChainExpression(_)))
                    && call_expr.callee.is_identifier_reference())
                => {
                    if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        &mut call_expr.callee,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    ) {
                        return Some(changed);
                    }

                    // Do not substitute our unconditionally-executed value into a branch
                    // unless the value itself has no side effects
                    if !replacement_has_side_effect || !call_expr.optional {
                        for arg in &mut call_expr.arguments {
                            match arg {
                                Argument::SpreadElement(spread_elem) => {
                                    if let Some(changed) =
                                        Self::substitute_single_use_symbol_in_expression(
                                            &mut spread_elem.argument,
                                            search_for,
                                            replacement,
                                            replacement_has_side_effect,
                                            ctx,
                                        )
                                    {
                                        return Some(changed);
                                    }
                                    // spread element may have sideeffects
                                    return Some(false);
                                }
                                match_expression!(Argument) => {
                                    if let Some(changed) =
                                        Self::substitute_single_use_symbol_in_expression(
                                            arg.to_expression_mut(),
                                            search_for,
                                            replacement,
                                            replacement_has_side_effect,
                                            ctx,
                                        )
                                    {
                                        return Some(changed);
                                    }
                                }
                            }
                        }
                    }
                }
            Expression::NewExpression(new_expr)
                // Don't substitute something into a call target that could change "this"
                if !((replacement.is_member_expression()
                    || matches!(replacement, Expression::ChainExpression(_)))
                    && new_expr.callee.is_identifier_reference())
                => {
                    if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        &mut new_expr.callee,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    ) {
                        return Some(changed);
                    }

                    for arg in &mut new_expr.arguments {
                        match arg {
                            Argument::SpreadElement(spread_elem) => {
                                if let Some(changed) =
                                    Self::substitute_single_use_symbol_in_expression(
                                        &mut spread_elem.argument,
                                        search_for,
                                        replacement,
                                        replacement_has_side_effect,
                                        ctx,
                                    )
                                {
                                    return Some(changed);
                                }
                                // spread element may have sideeffects
                                return Some(false);
                            }
                            match_expression!(Argument) => {
                                if let Some(changed) =
                                    Self::substitute_single_use_symbol_in_expression(
                                        arg.to_expression_mut(),
                                        search_for,
                                        replacement,
                                        replacement_has_side_effect,
                                        ctx,
                                    )
                                {
                                    return Some(changed);
                                }
                            }
                        }
                    }
                }
            Expression::ArrayExpression(array_expr) => {
                for elem in &mut array_expr.elements {
                    match elem {
                        ArrayExpressionElement::SpreadElement(spread_elem) => {
                            if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                                &mut spread_elem.argument,
                                search_for,
                                replacement,
                                replacement_has_side_effect,
                                ctx,
                            ) {
                                return Some(changed);
                            }
                            // spread element may have sideeffects
                            return Some(false);
                        }
                        ArrayExpressionElement::Elision(_) => {}
                        match_expression!(ArrayExpressionElement) => {
                            if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                                elem.to_expression_mut(),
                                search_for,
                                replacement,
                                replacement_has_side_effect,
                                ctx,
                            ) {
                                return Some(changed);
                            }
                        }
                    }
                }
            }
            Expression::ObjectExpression(obj_expr) => {
                for prop in &mut obj_expr.properties {
                    match prop {
                        ObjectPropertyKind::ObjectProperty(prop) => {
                            if prop.computed {
                                if let Some(changed) =
                                    Self::substitute_single_use_symbol_in_expression(
                                        prop.key.to_expression_mut(),
                                        search_for,
                                        replacement,
                                        replacement_has_side_effect,
                                        ctx,
                                    )
                                {
                                    return Some(changed);
                                }
                                // Stop now because computed keys have side effects
                                return Some(false);
                            }

                            if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                                &mut prop.value,
                                search_for,
                                replacement,
                                replacement_has_side_effect,
                                ctx,
                            ) {
                                if prop.shorthand && prop.key.is_specific_id("__proto__") {
                                    // { __proto__ } -> { ['__proto__']: value }
                                    prop.computed = true;
                                    prop.key = PropertyKey::new_string_literal(prop.key.span(), "__proto__", None, ctx);
                                }
                                prop.shorthand = false;
                                return Some(changed);
                            }
                        }
                        ObjectPropertyKind::SpreadProperty(prop) => {
                            if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                                &mut prop.argument,
                                search_for,
                                replacement,
                                replacement_has_side_effect,
                                ctx,
                            ) {
                                return Some(changed);
                            }
                            // Stop now because spread properties have side effects
                            return Some(false);
                        }
                    }
                }
            }
            Expression::TaggedTemplateExpression(tagged_expr) => {
                if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                    &mut tagged_expr.tag,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                ) {
                    return Some(changed);
                }
                for elem in &mut tagged_expr.quasi.expressions {
                    if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        elem,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    ) {
                        return Some(changed);
                    }
                }
            }
            Expression::TemplateLiteral(template_literal) => {
                for elem in &mut template_literal.expressions {
                    if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        elem,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    ) {
                        return Some(changed);
                    }
                }
            }
            Expression::ChainExpression(chain_expr) => {
                let mut expr = Expression::from(chain_expr.expression.take_in(ctx));
                let changed = Self::substitute_single_use_symbol_in_expression(
                    &mut expr,
                    search_for,
                    replacement,
                    replacement_has_side_effect,
                    ctx,
                );
                chain_expr.expression = expr.into_chain_element().expect("should be chain element");
                return changed;
            }
            Expression::SequenceExpression(sequence_expr) => {
                for expr in &mut sequence_expr.expressions {
                    if let Some(changed) = Self::substitute_single_use_symbol_in_expression(
                        expr,
                        search_for,
                        replacement,
                        replacement_has_side_effect,
                        ctx,
                    ) {
                        return Some(changed);
                    }
                }
            }
            _ => {}
        }

        // If both the replacement and this expression have no observable side
        // effects, then we can reorder the replacement past this expression
        //
        // ```js
        // // Substitution is ok
        // let replacement = 123;
        // return x + replacement;
        //
        // // Substitution is not ok because "fn()" may change "x"
        // let replacement = fn();
        // return x + replacement;
        //
        // // Substitution is not ok because "x == x" may change "x" due to "valueOf()" evaluation
        // let replacement = [x];
        // return (x == x) + replacement;
        // ```
        if !replacement_has_side_effect && !target_expr.may_have_side_effects(ctx) {
            return None;
        }

        // We can always reorder past literal values
        if replacement.is_literal_value(true, ctx) || target_expr.is_literal_value(true, ctx) {
            return None;
        }

        // Otherwise we should stop trying to substitute past this point
        Some(false)
    }

    /// Returns `true` if the statement is an unconditional termination that can be
    /// safely removed:
    /// - Unlabeled `continue` statements that terminate a loop body
    /// - Bare `return` statements that terminate a function body
    fn can_remove_termination_statement(stmt: &Statement<'a>, ctx: &TraverseCtx<'a>) -> bool {
        match stmt {
            // unlabeled `continue;` that terminates a `for`, `for...in`, `for...of`, `while`, `do...while` body.
            Statement::ContinueStatement(stmt) if stmt.label.is_none() => {
                matches!(
                    ctx.ancestor(1),
                    Ancestor::ForStatementBody(_)
                        | Ancestor::ForInStatementBody(_)
                        | Ancestor::ForOfStatementBody(_)
                        | Ancestor::WhileStatementBody(_)
                        | Ancestor::DoWhileStatementBody(_)
                )
            }
            // unlabeled `break;` that terminates a `do...while` body if test is false.
            Statement::BreakStatement(stmt) if stmt.label.is_none() => match ctx.ancestor(1) {
                Ancestor::DoWhileStatementBody(do_while) => {
                    do_while.test().get_side_free_boolean_value(ctx) == Some(false)
                }
                _ => false,
            },
            // bare `return;` in function-body scope.
            Statement::ReturnStatement(stmt) if stmt.argument.is_none() => {
                ctx.parent().is_function_body()
            }
            _ => false,
        }
    }
}

#[derive(Default)]
struct FindNestedBreak {
    found_unlabelled_break: bool,
}

impl FindNestedBreak {
    fn has_unlabelled_break_in_switch_case(node: &SwitchCase) -> bool {
        let mut visitor = Self::default();
        visitor.visit_switch_case(node);
        visitor.found_unlabelled_break
    }
}

impl<'a> VisitJs<'a> for FindNestedBreak {
    fn visit_expression(&mut self, _it: &Expression<'a>) {
        // do nothing
    }

    fn visit_statement(&mut self, it: &Statement<'a>) {
        if self.found_unlabelled_break || it.is_declaration() || it.is_iteration_statement() {
            return;
        }
        match it {
            Statement::ThrowStatement(_)
            | Statement::SwitchStatement(_)
            | Statement::ContinueStatement(_)
            | Statement::ReturnStatement(_)
            | Statement::ExpressionStatement(_) => {}
            Statement::BreakStatement(it) if it.label.is_none() => {
                self.found_unlabelled_break = true;
            }
            _ => walk_js::walk_statement(self, it),
        }
    }
}
