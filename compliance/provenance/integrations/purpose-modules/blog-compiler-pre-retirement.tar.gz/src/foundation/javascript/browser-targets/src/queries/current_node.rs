#[cfg(any(not(target_arch = "wasm32"), feature = "wasm_bindgen"))]
use super::Distrib;
use super::QueryResult;
use crate::error::Error;

pub(super) fn current_node() -> QueryResult {
    #[cfg(target_arch = "wasm32")]
    {
        #[cfg(feature = "wasm_bindgen")]
        {
            use js_sys::{Reflect, global};

            let obj_process = Reflect::get(&global(), &"process".into())
                .map_err(|_| Error::UnsupportedCurrentNode)?;
            let obj_versions = Reflect::get(&obj_process, &"versions".into())
                .map_err(|_| Error::UnsupportedCurrentNode)?;
            let version = Reflect::get(&obj_versions, &"node".into())
                .map_err(|_| Error::UnsupportedCurrentNode)?
                .as_string()
                .ok_or(Error::UnsupportedCurrentNode)?;
            return Ok(vec![Distrib::new("node", version)]);
        }

        #[cfg(not(feature = "wasm_bindgen"))]
        Err(Error::UnsupportedCurrentNode)
    }

    #[cfg(not(target_arch = "wasm32"))]
    {
        use std::{process::Command, sync::OnceLock};

        static CURRENT_NODE: OnceLock<QueryResult> = OnceLock::new();

        CURRENT_NODE
            .get_or_init(|| {
                let output = Command::new("node")
                    .arg("-v")
                    .output()
                    .map_err(|_| Error::UnsupportedCurrentNode)?;
                let version = String::from_utf8_lossy(&output.stdout)
                    .trim()
                    .trim_start_matches('v')
                    .to_owned();

                Ok(vec![Distrib::new("node", version)])
            })
            .clone()
    }
}
