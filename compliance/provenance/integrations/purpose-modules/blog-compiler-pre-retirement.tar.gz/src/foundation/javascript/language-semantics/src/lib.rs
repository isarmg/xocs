//! Methods defined in the [ECMAScript Language Specification](https://tc39.es/ecma262).
//!
//! # Cargo features
//!
//! - `side_effects`: Enables side-effect analysis.
//! - `constant_evaluation`: Enables constant evaluation and implies `side_effects`.

// [Syntax-Directed Operations](https://tc39.es/ecma262/#sec-syntax-directed-operations)
mod bound_names;
mod is_simple_parameter_list;
mod private_bound_identifiers;
mod prop_name;

// Abstract Operations
mod array_join;
#[cfg(feature = "constant_evaluation")]
mod is_less_than;
mod string_char_at;
mod string_char_code_at;
mod string_index_of;
mod string_last_index_of;
mod string_substring;
mod string_to_big_int;
mod string_to_number;
mod to_big_int;
mod to_boolean;
mod to_int_32;
mod to_integer_or_infinity;
mod to_number;
mod to_numeric;
mod to_primitive;
mod to_string;
mod value;
mod value_type;

// other
mod to_integer_index;

#[cfg(feature = "constant_evaluation")]
pub mod constant_evaluation;
mod global_context;
mod number_literal;
#[cfg(feature = "side_effects")]
pub mod side_effects;

pub use self::{
    array_join::ArrayJoin,
    bound_names::BoundNames,
    global_context::{GlobalContext, WithoutGlobalReferenceInformation},
    is_simple_parameter_list::IsSimpleParameterList,
    number_literal::with_number_literal,
    private_bound_identifiers::PrivateBoundIdentifiers,
    prop_name::PropName,
    string_char_at::{StringCharAt, StringCharAtResult},
    string_char_code_at::StringCharCodeAt,
    string_index_of::StringIndexOf,
    string_last_index_of::StringLastIndexOf,
    string_substring::StringSubstring,
    string_to_big_int::StringToBigInt,
    string_to_number::StringToNumber,
    to_big_int::ToBigInt,
    to_boolean::ToBoolean,
    to_int_32::{ToInt32, ToUint32},
    to_integer_index::ToIntegerIndex,
    to_number::ToNumber,
    to_primitive::ToPrimitive,
    to_string::ToJsString,
    value::ConstantValue,
    value_type::{DetermineValueType, ValueType},
};
