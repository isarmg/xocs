// Stable toolchain 1.99; no compiler-channel probing.
fn main() {}
